/* ahkam_glyph.js — قراءة نص كروكي AutoCAD من أرقام الحروف المرسومة (Glyph IDs) مباشرةً — v52
   المشكلة: AutoCAD يكتب في الـPDF جدول ترميز (ToUnicode) خاطئًا لخط Calibri العربي، فيخرج «عبدالله» كـ«عبثيشله»
   مع أن الشكل المرسوم سليم. الحل: نقرأ رقم كل حرف مرسوم (originalCharCode) ونحوّله لحرفه الصحيح من جدول مستخرج
   من الخط نفسه (GSUB + أسماء الحروف)، فنحصل على النص حرفًا بحرف دون OCR.
   - T1: حروف مؤكدة (أسماء الحروف داخل الخط نفسه + كل أشكالها: أول/وسط/آخر/منفصل)
   - T2: حروف مستنتجة من ترتيب الخط (آ أ إ ؤ خ ذ ز ص ض ظ غ ف ق ن) — تُقبل بثقة أقل ما لم يؤكدها OCR/قائمة معروفة
   - أي رقم غير موجود في الجدول ⇒ يُعاد ‹unknown› ولا نخمّن (يعود النظام للـOCR) */
(function(root){
'use strict';
const T1={"4712":"ا","4722":"ا","4729":"ب","4750":"ب","4771":"ب","4792":"ب","4730":"ت","4751":"ت","4772":"ت","4793":"ت","4731":"ث","4752":"ث","4773":"ث","4794":"ث","4813":"ج","4831":"ج","4849":"ج","4867":"ج","4814":"ح","4832":"ح","4850":"ح","4868":"ح","4885":"د","4900":"د","4915":"ر","4933":"ر","4951":"س","4962":"س","4973":"س","4984":"س","4952":"ش","4963":"ش","4974":"ش","4985":"ش","5019":"ط","5023":"ط","5027":"ط","5031":"ط","5035":"ع","5043":"ع","5051":"ع","5059":"ع","5127":"ك","5147":"ك","5167":"ك","5187":"ك","5211":"ل","5218":"ل","5225":"ل","5232":"ل","5239":"م","5243":"م","5247":"م","5251":"م","5291":"ه","5295":"ه","5299":"ه","5303":"ه","5318":"و","5335":"و","5356":"ى","5373":"ى","5390":"ى","5407":"ى","5357":"ي","5374":"ي","5391":"ي","5408":"ي","5312":"ة","5307":"ة","5308":"ة","5315":"ة","5461":"لا","5465":"لا","3":" "};
const T2={"4709":"آ","4719":"آ","4710":"أ","4720":"أ","4711":"إ","4721":"إ","4815":"خ","4833":"خ","4851":"خ","4869":"خ","4886":"ذ","4901":"ذ","4916":"ز","4934":"ز","4995":"ص","5001":"ص","5007":"ص","5013":"ص","4996":"ض","5002":"ض","5008":"ض","5014":"ض","5020":"ظ","5024":"ظ","5028":"ظ","5032":"ظ","5036":"غ","5044":"غ","5052":"غ","5060":"غ","5067":"ف","5077":"ف","5087":"ف","5097":"ف","5107":"ق","5112":"ق","5117":"ق","5122":"ق","5255":"ن","5264":"ن","5273":"ن","5282":"ن","5317":"ؤ","5334":"ؤ"};
const DIG={876:'/',882:'-',1004:'0',1005:'1',1006:'2',1007:'3',1008:'4',1009:'5',1010:'6',1011:'7',1012:'8',1013:'9'};
/* codes بترتيب الرسم من اليسار لليمين ⇒ نص منطقي (يمين←يسار) مع إبقاء الأرقام بترتيبها */
function decode(codes){
  const toks=[];let unknown=0,inferred=0;
  for(const c of codes){
    let a=T1[c];
    if(a===undefined)a=DIG[c];
    if(a!==undefined){toks.push(a);continue}
    const b=T2[c];
    if(b!==undefined){toks.push(b);inferred++;continue}
    unknown++;toks.push('\u0000');
  }
  let text=toks.reverse().join('').replace(/[0-9\/]+/g,m=>[...m].reverse().join(''));
  return {text,unknown,inferred};
}
const mul=(a,b)=>[a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3],a[4]*b[0]+a[5]*b[2]+b[4],a[4]*b[1]+a[5]*b[3]+b[5]];
const isCalibri=n=>/(^|\+)Calibri$/i.test(String(n||''));
/* يعيد مقاطع النص العربية (كل showText) بموضعها في فضاء الصفحة (نفس إحداثيات pdf.js textContent) */
async function readRuns(lib,page){
  const OPS=lib.OPS,ol=await page.getOperatorList();
  let ctm=[1,0,0,1,0,0],tm=[1,0,0,1,0,0],tlm=[1,0,0,1,0,0],font=null,fsize=0,hs=1,cs=0,ws=0;
  const st=[],runs=[],fontOk={};
  const okFont=id=>{
    if(id in fontOk)return fontOk[id];
    let ok=false;
    try{if(page.commonObjs.has(id))ok=isCalibri((page.commonObjs.get(id)||{}).name)}catch(e){}
    return fontOk[id]=ok;
  };
  for(let i=0;i<ol.fnArray.length;i++){
    const f=ol.fnArray[i],a=ol.argsArray[i];
    switch(f){
      case OPS.save:st.push({ctm:ctm.slice(),font,fsize});break;
      case OPS.restore:{const s=st.pop();if(s){ctm=s.ctm;font=s.font;fsize=s.fsize}break}
      case OPS.transform:ctm=mul(a,ctm);break;
      case OPS.paintFormXObjectBegin:st.push({ctm:ctm.slice(),font,fsize});if(a&&a[0])ctm=mul(a[0],ctm);break;
      case OPS.paintFormXObjectEnd:{const s=st.pop();if(s){ctm=s.ctm;font=s.font;fsize=s.fsize}break}
      case OPS.beginText:tm=[1,0,0,1,0,0];tlm=tm.slice();break;
      case OPS.setTextMatrix:{const mm=Array.from(a.length===1&&typeof a[0]==='object'?a[0]:a);tm=mm;tlm=mm.slice();break}
      case OPS.moveText:tlm=mul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case OPS.setLeadingMoveText:tlm=mul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case OPS.setFont:font=a[0];fsize=a[1];break;
      case OPS.setCharSpacing:cs=a[0];break;
      case OPS.setWordSpacing:ws=a[0];break;
      case OPS.setHScale:hs=a[0]/100;break;
      case OPS.showText:{
        const gl=(a[0]||[]).filter(g=>g&&typeof g==='object');
        if(!gl.length)break;
        let adv=0;for(const g of gl)adv+=(g.width||0)*fsize*0.001*hs+cs*hs+(g.isSpace?ws*hs:0);
        const m=mul(tm,ctm);
        const sx=Math.hypot(m[0],m[1]),sy=Math.hypot(m[2],m[3]);
        const w=Math.abs(adv)*sx,h=Math.abs(fsize)*sy;
        const ok=okFont(font);
        const codes=gl.map(g=>g.originalCharCode);
        runs.push({x:m[4],y:m[5],w,h,codes,ok,uni:gl.map(g=>g.unicode||'').join(''),
          dec:ok?decode(codes):null});
        tm=mul([1,0,0,1,adv,0],tm);
        break}
    }
  }
  return runs;
}
/* يجمع مقاطع منطقة واحدة (عربي: من اليمين لليسار) ⇒ {text,unknown,inferred,complete} */
function joinRuns(rs){
  const arr=rs.filter(r=>r.dec).sort((a,b)=>(b.x+b.w/2)-(a.x+a.w/2));
  let text='',unknown=0,inferred=0;
  for(const r of arr){text+=(text?' ':'')+r.dec.text;unknown+=r.dec.unknown;inferred+=r.dec.inferred}
  text=text.replace(/\s+/g,' ').trim();
  return {text,unknown,inferred,complete:arr.length>0&&unknown===0&&text.replace(/\s/g,'').length>0,runs:arr.length};
}
root.AhkamGlyph={decode,readRuns,joinRuns,T1,T2};
if(typeof module!=='undefined'&&module.exports)module.exports=root.AhkamGlyph;
})(typeof window!=='undefined'?window:globalThis);
