/* ahkam_ai.js — قراءة ذكية للكروكي بواسطة Claude (رؤية) — دقة أعلى بكثير من OCR المجاني
   يُرسل صورة الصفحة إلى واجهة Anthropic (يحتاج إنترنت + مفتاح API). المفتاح يُحفظ في هذا المتصفح فقط. */
(function(root){
'use strict';
const KEY='ahkam_ai_key',MODEL='claude-sonnet-4-6';
const getKey=()=>{try{return localStorage.getItem(KEY)||''}catch(e){return ''}};
const setKey=k=>{try{k?localStorage.setItem(KEY,k):localStorage.removeItem(KEY)}catch(e){}};
async function renderJpeg(lib,buf,maxW){
  const pdf=await lib.getDocument({data:new Uint8Array(buf)}).promise;
  const page=await pdf.getPage(1),v1=page.getViewport({scale:1});
  const scale=Math.min(3,maxW/v1.width),vp=page.getViewport({scale});
  const cv=document.createElement('canvas');cv.width=Math.ceil(vp.width);cv.height=Math.ceil(vp.height);
  const cx=cv.getContext('2d');cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);
  await page.render({canvasContext:cx,viewport:vp}).promise;
  return cv.toDataURL('image/jpeg',0.92).split(',')[1];
}
const PROMPT=`هذا كروكي مساحي سعودي (أمانة/بلدية). اقرأ بيانات الجداول العلوية فقط (ليس الخريطة) وأعد JSON فقط بلا أي شرح وبلا علامات markdown، بالمفاتيح التالية بالضبط:
{"رقم الطلب":"","اسم المالك":"","رقم السجل":"","الاستخدام":"","المنطقة":"","المدينة":"","الموقع":"","التاريخ":""}
القواعد:
- اسم المالك: الاسم الكامل كما هو مكتوب بجوار «المالك».
- رقم السجل: رقم السجل المدني/الهوية بأرقام لاتينية 0-9 فقط.
- المنطقة: المنطقة الإدارية كاملة (مثل مكة المكرمة). المدينة: قيمة «المحافظة» (مثل جدة).
- الموقع: اسم الحي بدون كلمة «حي».
- الاستخدام: واحدة من (سكني، تجاري، سكني تجاري، زراعي) إن ذُكر صراحة وإلا فارغ.
- التاريخ: تاريخ الطلب الهجري بصيغة يوم/شهر/سنة؛ وإن كان فارغًا أو شرطات فاستخدم «تاريخ الرفع المساحي».
- أي قيمة فارغة أو شرطات اكتبها "". حوّل الأرقام الهندية إلى 0-9. لا تخمّن: إن لم تتأكد اتركها "".`;
async function readPdf(lib,buf){
  const key=getKey();if(!key)throw new Error('ERR_AI_NOKEY');
  const img=await renderJpeg(lib,buf,2400);
  const ac=new AbortController(),acT=setTimeout(()=>ac.abort(),40000);
  let r;try{r=await fetch('https://api.anthropic.com/v1/messages',{signal:ac.signal,method:'POST',
    headers:{'content-type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},
    body:JSON.stringify({model:MODEL,max_tokens:700,messages:[{role:'user',content:[
      {type:'image',source:{type:'base64',media_type:'image/jpeg',data:img}},{type:'text',text:PROMPT}]}]})})}finally{clearTimeout(acT)}
  if(r.status===401)throw new Error('ERR_AI_BADKEY');
  if(!r.ok)throw new Error('ERR_AI_HTTP_'+r.status+' '+(await r.text()).slice(0,200));
  const j=await r.json();
  const txt=(j.content||[]).map(c=>c.text||'').join('').replace(/```json|```/g,'').trim();
  const m=txt.match(/\{[\s\S]*\}/);if(!m)throw new Error('ERR_AI_PARSE');
  const o=JSON.parse(m[0]),fields={};
  for(const k in o){
    let v=String(o[k]==null?'':o[k]).trim();
    if(!v||/^[-–—\/\s.]+$/.test(v))continue;
    if(k==='التاريخ'){const h=AhkamPdf.parseHijri(v);if(!h)continue;v=h.d+'/'+h.m+'/'+h.y}
    if(k==='رقم السجل'){v=AhkamPdf.clean(v).replace(/\D/g,'');if(!v)continue}
    fields[k]={value:v,conf:0.8,how:'Claude',page:1,label:''};
  }
  return {fields,pages:1,text:txt,hasText:true,viaAI:true,arCount:999};
}
root.AhkamAI={readPdf,getKey,setKey};
})(window);
