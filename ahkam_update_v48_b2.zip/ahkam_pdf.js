/* ahkam_pdf.js — قراءة ذكية لكروكي PDF المساحي واستخراج بيانات الطلب (v48)
   يعمل دون إنترنت: pdf.js محلي داخل مجلد pdfjs. لا يعتمد على تخطيط ثابت؛ يتعرف على:
   - ترتيب النص (منطقي أو بصري معكوس) ويصحّحه تلقائيًا
   - جداول (عنوان | قيمة) وصيغة «عنوان: قيمة» والقيمة تحت العنوان
   - الأرقام العربية/الفارسية والتاريخ الهجري واختلاف الهمزات والتاء المربوطة */
(function(root){
'use strict';
const AR_IND='٠١٢٣٤٥٦٧٨٩',PERS='۰۱۲۳۴۵۶۷۸۹';
const hasAr=s=>/[\u0600-\u06FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(s);
function digits(s){return String(s).replace(/[٠-٩]/g,d=>AR_IND.indexOf(d)).replace(/[۰-۹]/g,d=>PERS.indexOf(d)).replace(/٫/g,'.').replace(/٬/g,',')}
function clean(s){return digits(String(s==null?'':s).normalize('NFKC').replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\u061c\ufeff]/g,'').replace(/\s+/g,' ').trim())}
function nk(s){return clean(s).replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/ؤ/g,'و').replace(/ئ/g,'ي')}
function revVisual(s){const r=[...s].reverse().join('');return r.replace(/[0-9A-Za-z][0-9A-Za-z.,\/:\-]*/g,m=>[...m].reverse().join(''))}
const TASH='[\\u064B-\\u065F\\u0670\\u0640]*';
function labelRx(label){
  const L=nk(label);let out=[];
  for(const c of L){
    if(c===' ')out.push('\\s*');
    else if(c==='ا')out.push('[اأإآٱ]');else if(c==='ي')out.push('[يى]');else if(c==='ه')out.push('[هة]');else if(c==='و')out.push('[وؤ]');
    else out.push(c.replace(/[.*+?^${}()|[\]\\\/]/g,'\\$&'));
  }
  return out.join(TASH);
}
const FIELDS=[
 {key:'رقم الطلب',kind:'req',labels:['رقم الطلب او المعامله','رقم الطلب','رقم المعامله','رقم طلب','طلب رقم','رقم المعاملة']},
 {key:'اسم المالك',kind:'name',labels:['اسم المالك','اسم صاحب الطلب','اسم مقدم الطلب','اسم طالب الخدمه','اسم صاحب الصك','اسم المستفيد','اسم العميل','اسم الملاك','مقدم الطلب','صاحب الطلب','المالك','الملاك']},
 {key:'رقم السجل',kind:'id',labels:['رقم السجل المدني','رقم الهويه الوطنيه','رقم الهويه','رقم السجل','السجل المدني','رقم الهويه/الاقامه','هويه']},
 {key:'المنطقة',kind:'region',labels:['المنطقه الاداريه','المنطقه','منطقه']},
 {key:'المدينة',kind:'city',labels:['المدينه','المحافظه','البلديه','الامانه','المدينه/المحافظه']},
 {key:'الموقع',kind:'loc',labels:['اسم المخطط','اسم الحي','الموقع','الحي','المخطط','القريه','المركز','حي']},
 {key:'التاريخ',kind:'hijri',labels:['تاريخ الطلب','تاريخ الكروكي','تاريخ الرفع المساحي','تاريخ']},
 {key:'الاستخدام',kind:'use',labels:['نوع الاستخدام','الاستخدام','الغرض','نوع الارض']},
 {key:'رقم القطعة',kind:'code',labels:['رقم القطعه','القطعه رقم','قطعه رقم','القطعه']},
 {key:'رقم المخطط',kind:'code',labels:['رقم المخطط','مخطط رقم']},
 {key:'رقم الصك',kind:'code',labels:['رقم الصك','صك رقم']},
 {key:'المساحة (الكروكي)',kind:'area',labels:['المساحه الاجماليه','مساحه القطعه','مساحه الارض','المساحه بالكروكي','المساحه']},
 {key:'المساحة حسب الصك',kind:'area',deed:true,labels:['المساحه حسب الصك','مساحه الصك','المساحه بالصك','مساحه حسب الصك']}
];
const REGIONS=['مكة المكرمة','المدينة المنورة','الرياض','القصيم','المنطقة الشرقية','عسير','تبوك','حائل','الحدود الشمالية','جازان','نجران','الباحة','الجوف'];
const ALL_LABELS_RX=new RegExp('(?:'+[].concat(...FIELDS.map(f=>f.labels)).sort((a,b)=>b.length-a.length).map(labelRx).join('|')+')');
FIELDS.forEach(f=>{f.rx=f.labels.map(l=>({l,re:new RegExp(labelRx(l))}))});

const AR='[\\u0600-\\u06FF\\uFB50-\\uFDFF\\uFE70-\\uFEFF]';
const RUN_RX=new RegExp('(?:(?<![\\d.,\\/\\-])\\d+[ ]+)*\\d*'+AR+'+(?:[ ]+(?:(?<![\\d.,\\/\\-])\\d+[ ]+)*\\d*'+AR+'+)*','g');
function fixText(s,mode,dir){
  if(mode==='normal'||!hasAr(s))return clean(s);
  const d=digits(String(s).normalize('NFKC'));
  if(mode==='dir'){
    // pdf.js يعيد ترتيب المقاطع العربية بصريًا: rtl ⇒ السلسلة كلها، ltr ⇒ كل مقطع عربي داخل السلسلة فقط
    if(dir==='rtl')return clean(revVisual(d));
    return clean(d.replace(RUN_RX,run=>revVisual(run)));
  }
  if(mode==='visA')return clean(revVisual(d));            // نص بصري: الأرقام مرسومة بترتيبها الصحيح
  return clean([...d].reverse().join(''));                 // نص عُكس كاملًا (مثل عكس pdf.js للمقاطع العربية)
}
function buildRows(page,mode){
  const its=page.items.map(i=>({x:i.x,y:i.y,w:i.w,h:i.h,s:fixText(i.s,mode,i.dir)})).filter(i=>i.s);
  its.sort((a,b)=>b.y-a.y||a.x-b.x);
  const rows=[];
  for(const it of its){
    let r=rows.find(r=>Math.abs(r.y-it.y)<=Math.max(2,0.45*Math.min(r.h,it.h)));
    if(!r){r={y:it.y,h:it.h,its:[]};rows.push(r)}
    r.its.push(it);
  }
  rows.sort((a,b)=>b.y-a.y);
  rows.forEach(r=>{
    r.its.sort((a,b)=>a.x-b.x);
    const cells=[];let cur=null;
    for(const it of r.its){
      if(cur&&it.x-cur.x1<=0.8*r.h){cur.parts.push(it);cur.x1=Math.max(cur.x1,it.x+it.w)}
      else{cur={parts:[it],x0:it.x,x1:it.x+it.w};cells.push(cur)}
    }
    cells.forEach(c=>{
      const ar=c.parts.filter(p=>hasAr(p.s)).length*2>=c.parts.length;
      const ps=ar?c.parts.slice().sort((a,b)=>b.x-a.x):c.parts;
      c.text=ps.map(p=>p.s).join(' ').replace(/\s+/g,' ').trim();
    });
    r.cells=cells;
  });
  return rows;
}
function trimVal(s){return String(s||'').replace(/^[\s:：\-–—\/\.\u061b]+/,'').replace(/[\s:：\-–—\/]+$/,'').trim()}
function cutAtNextLabel(s){const m=ALL_LABELS_RX.exec(nk(s));if(!m)return s;
  // الموضع في النص الأصلي: نبحث بالتعبير نفسه على النص المنظّف
  const m2=ALL_LABELS_RX.exec(s);return m2?s.slice(0,m2.index):s}
function parseHijri(s){
  const t=clean(s).replace(/[هـة]+/g,' ');let m=t.match(/(\d{1,2})\s*[\/\-.]\s*(\d{1,2})\s*[\/\-.]\s*(1[34]\d{2})(?!\d)/);
  if(m)return {d:+m[1],m:+m[2],y:+m[3]};
  m=t.match(/(?<!\d)(1[34]\d{2})\s*[\/\-.]\s*(\d{1,2})\s*[\/\-.]\s*(\d{1,2})(?!\d)/);
  if(m)return {d:+m[3],m:+m[2],y:+m[1]};
  return null;
}
const UNIT_RX=/(?:م\s*[2²]|[2²]\s*م|متر(?:\s*مربع)?|\bm\s*[2²]|\bsqm\b)/gi;
function parseNum(s){const m=clean(s).replace(UNIT_RX,' ').replace(/(\d),(\d{1,2})(?!\d)/g,'$1.$2').match(/(\d{1,3}(?:,\d{3})+|\d+)(\.\d+)?/);if(!m)return null;const v=Number((m[1]+(m[2]||'')).replace(/,/g,''));return isFinite(v)?v:null}
function mapUse(s){const t=nk(s);if(/تجاري/.test(t)&&/سكني/.test(t))return 'سكني تجاري';if(/سكني/.test(t))return 'سكني';if(/زراع/.test(t))return 'زراعي';if(/تجار/.test(t))return 'تجاري';if(/صناع/.test(t))return 'صناعي';if(/حكوم/.test(t))return 'حكومي';if(/استثمار/.test(t))return 'استثماري';return null}
function validate(kind,raw){
  let v=trimVal(cutAtNextLabel(clean(raw)));if(!v)return null;
  switch(kind){
    case 'req':{const m=v.match(/\d[\d\/\-.]{3,}\d/);return m?m[0]:null}
    case 'id':{const m=v.match(/(?<!\d)[12]\d{9}(?!\d)/);return m?m[0]:null}
    case 'name':{v=v.split(/\d/)[0].trim();if(v.length<4||!hasAr(v)||ALL_LABELS_RX.test(nk(v)))return null;return v.length>60?null:v}
    case 'region':case 'city':{v=v.split(/\d/)[0].trim();if(v.length<2||v.length>40||!hasAr(v)||ALL_LABELS_RX.test(nk(v)))return null;return v}
    case 'loc':{if(v.length<2||v.length>90||!hasAr(v)||ALL_LABELS_RX.test(nk(v)))return null;return v}
    case 'hijri':{const h=parseHijri(v);return h?h.d+'/'+h.m+'/'+h.y:null}
    case 'use':return mapUse(v);
    case 'code':{const m=v.match(/^[0-9A-Za-z\u0600-\u06FF\/\-]{1,24}/);return m&&/\d/.test(m[0])?m[0]:null}
    case 'area':{const n=parseNum(v);return n&&n>=1&&n<1e9?String(n):null}
  }
  return null;
}
function afterLabel(text,re){const m=re.exec(text);return m?text.slice(m.index+m[0].length):null}
function findField(f,pages,rtl){
  let best=null;
  const offer=(value,conf,how,pn,lbl)=>{if(value==null)return;if(!best||conf>best.conf)best={value,conf,how,page:pn,label:lbl}};
  for(const pg of pages){
    pg.rows.forEach((row,ri)=>{
      row.cells.forEach((cell,ci)=>{
        for(const {l,re} of f.rx){
          const nkt=cell.text;
          if(!re.test(nkt))continue;
          if(f.kind==='area'&&!f.deed&&/الصك/.test(nkt))continue;           // المساحة حسب الصك لها حقلها
          if(f.kind==='req'&&/(?:\d)/.test(nkt.replace(re,'')) ){/* قد تحوي القيمة في الخلية نفسها */}
          // 1) في الخلية نفسها
          const rest=afterLabel(nkt,re);
          if(rest!=null){const v=validate(f.kind,rest);if(v!=null)offer(v,0.92,'inline',pg.pn,l)}
          // 2) خلية مجاورة في الصف نفسه
          const sibs=row.cells.map((c,i)=>({c,i})).filter(o=>o.i!==ci);
          const left=sibs.filter(o=>o.c.x1<=cell.x0+2).sort((a,b)=>b.c.x1-a.c.x1);
          const right=sibs.filter(o=>o.c.x0>=cell.x1-2).sort((a,b)=>a.c.x0-b.c.x0);
          const order=rtl?left.concat(right):right.concat(left);
          for(const o of order){
            if(ALL_LABELS_RX.test(nk(o.c.text))&&!/\d/.test(o.c.text))continue;
            const v=validate(f.kind,o.c.text);if(v!=null){offer(v,rtl===(order===left.concat(right)||o.c.x1<=cell.x0+2)?0.86:0.8,'sibling',pg.pn,l);break}
          }
          // 3) أسفل العنوان
          for(let k=1;k<=2&&ri+k<pg.rows.length;k++){
            const below=pg.rows[ri+k].cells.filter(c=>Math.min(c.x1,cell.x1)-Math.max(c.x0,cell.x0)>0.25*(cell.x1-cell.x0)).sort((a,b)=>Math.abs((a.x0+a.x1)/2-(cell.x0+cell.x1)/2)-Math.abs((b.x0+b.x1)/2-(cell.x0+cell.x1)/2));
            let ok=false;
            for(const c of below){if(ALL_LABELS_RX.test(nk(c.text))&&!/\d/.test(c.text))continue;const v=validate(f.kind,c.text);if(v!=null){offer(v,0.68,'below',pg.pn,l);ok=true;break}}
            if(ok)break;
          }
        }
      });
    });
  }
  return best;
}
function detectRtl(pages){
  let r=0,l=0;
  for(const pg of pages)for(const row of pg.rows)for(const c of row.cells){
    if(ALL_LABELS_RX.test(c.text)){((c.x0+c.x1)/2>pg.w/2)?r++:l++}
  }
  return r>=l;
}
function parseMode(rawPages,mode){
  const pages=rawPages.map(pg=>({pn:pg.pn,w:pg.w,h:pg.h,rows:buildRows(pg,mode)}));
  const rtl=detectRtl(pages);
  const fields={};
  for(const f of FIELDS){const r=findField(f,pages,rtl);if(r)fields[f.key]=r}
  if(!fields['التاريخ']){
    for(const pg of pages){for(const row of pg.rows)for(const c of row.cells){const h=parseHijri(c.text);if(h){fields['التاريخ']={value:h.d+'/'+h.m+'/'+h.y,conf:0.55,how:'scan',page:pg.pn,label:''};break}}if(fields['التاريخ'])break}
  }
  if(!fields['المنطقة']){
    const all=nk(pages.map(p=>p.rows.map(r=>r.cells.map(c=>c.text).join(' ')).join(' ')).join(' '));
    for(const r of REGIONS){if(all.includes(nk(r))){fields['المنطقة']={value:r,conf:0.5,how:'scan',page:1,label:''};break}}
  }
  // نقاط الجودة: عدد الحقول + مكافآت للأنماط التي لا تتحقق إلا إذا كان ترتيب النص صحيحًا
  let score=0;for(const k in fields)score+=fields[k].conf;
  const h=fields['التاريخ']&&parseHijri(fields['التاريخ'].value);
  if(h&&h.y>=1400&&h.y<=1500)score+=1.5;
  if(fields['رقم السجل'])score+=1;
  if(fields['رقم الطلب']&&/\d\/\d/.test(fields['رقم الطلب'].value))score+=0.5;
  for(const k of ['المنطقة','المدينة'])if(fields[k]&&REGIONS.some(r=>nk(r)===nk(fields[k].value)))score+=0.5;
  return {pages,rtl,fields,score,mode};
}
function parseRows(rawPages,opts){
  const nItems=rawPages.reduce((a,p)=>a+p.items.length,0);
  let best=null;
  for(const mode of ((opts&&opts.modes)||['dir','normal','visB','visA'])){const r=parseMode(rawPages,mode);if(!best||r.score>best.score+0.01)best=r}
  const lines=best.pages.map(p=>p.rows.map(r=>r.cells.map(c=>c.text).join(' | ')).join('\n')).join('\n--- صفحة ---\n');
  const arCount=(lines.match(/[\u0600-\u06FF]/g)||[]).length;
  return {fields:best.fields,arCount,mode:best.mode,visualOrder:best.mode!=='normal',rtl:best.rtl,pages:rawPages.length,textItems:nItems,hasText:nItems>=5,text:lines};
}
async function readPdf(pdfjsLib,buf){
  let pdf;
  try{pdf=await pdfjsLib.getDocument({data:new Uint8Array(buf)}).promise}
  catch(e){if(e&&e.name==='PasswordException')throw new Error('ERR_PDF_PASSWORD');throw new Error('ERR_PDF_INVALID')}
  const raw=[];
  for(let pn=1;pn<=Math.min(pdf.numPages,8);pn++){
    const page=await pdf.getPage(pn),vp=page.getViewport({scale:1}),tc=await page.getTextContent();
    const items=[];
    for(const it of tc.items){
      if(typeof it.str!=='string'||!it.str.trim())continue;
      const tr=it.transform,h=Math.abs(it.height)||Math.hypot(tr[2],tr[3])||8;
      items.push({s:it.str,x:tr[4],y:tr[5],w:it.width||0,h,dir:it.dir});
    }
    raw.push({pn,w:vp.width,h:vp.height,items});
  }
  return parseRows(raw);
}
const isLabel=s=>ALL_LABELS_RX.test(nk(s));
const api={readPdf,parseRows,clean,nk,parseHijri,FIELDS,isLabel,hasAr};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.AhkamPdf=api;
})(typeof window!=='undefined'?window:globalThis);
