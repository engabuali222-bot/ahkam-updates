# Ahkam Tool updater (runs hidden, started by server.ps1 after a signed update package was verified).
# Waits for the old server to exit, swaps the files (keeping customer data), restarts the server,
# and automatically rolls everything back if the new server does not come up.
param([string]$Root, [int]$Port = 8799, [int]$ServerPid = 0)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$log = Join-Path $Root 'ahkam_update.log'
function L([string]$m) { try { Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $m) -Encoding UTF8 } catch { } }
L 'UPDATER_START'

$stage = Join-Path $Root 'update_tmp'
$src = Join-Path $stage 'new'
if (-not (Test-Path -LiteralPath $src)) { L 'NO_STAGING_FOLDER'; exit 1 }

# customer data and local settings are never overwritten
$never = @('ahkam_drafts.json', 'license.key', 'update.config.json', 'ahkam_server.log', 'ahkam_server_error.log', 'ahkam_update.log')
$srcFull = (Get-Item -LiteralPath $src).FullName.TrimEnd('\')
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$bak = Join-Path $Root ('backup\' + $stamp)
$changed = New-Object System.Collections.Generic.List[string]
$added = New-Object System.Collections.Generic.List[string]

function Stop-AhkamServers {
  try {
    Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*server.ps1*' -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch { }
}
function Start-AhkamServer {
  $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $srv = Join-Path $Root 'server.ps1'
  $q = [string][char]34
  Start-Process -FilePath $psExe -ArgumentList @('-NoLogo', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ($q + $srv + $q), '-Port', [string]$Port) -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardError (Join-Path $Root 'ahkam_server_error.log') | Out-Null
}
function Wait-Health([int]$sec) {
  for ($i = 0; $i -lt $sec; $i++) {
    try {
      $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 -Uri ('http://127.0.0.1:' + $Port + '/health')
      if ($r.StatusCode -eq 200 -and ([string]$r.Content).StartsWith('OK|')) { return $true }
    } catch { }
    Start-Sleep -Seconds 1
  }
  return $false
}
function Restore-Files {
  foreach ($rel in $changed) { try { Copy-Item -LiteralPath (Join-Path $bak $rel) -Destination (Join-Path $Root $rel) -Force } catch { L ('RESTORE_FAILED ' + $rel) } }
  foreach ($rel in $added) { try { Remove-Item -LiteralPath (Join-Path $Root $rel) -Force -ErrorAction SilentlyContinue } catch { } }
  L 'FILES_RESTORED'
}

# 1) wait until the old server has exited (it stops right after answering the browser)
if ($ServerPid -gt 0) {
  for ($i = 0; $i -lt 30; $i++) {
    if (-not (Get-Process -Id $ServerPid -ErrorAction SilentlyContinue)) { break }
    Start-Sleep -Milliseconds 500
  }
  if (Get-Process -Id $ServerPid -ErrorAction SilentlyContinue) { try { Stop-Process -Id $ServerPid -Force } catch { } }
}
Start-Sleep -Milliseconds 800

# 2) swap files (backup of every replaced file first)
$failed = $false
try {
  $files = Get-ChildItem -LiteralPath $src -Recurse -File
  foreach ($f in $files) {
    $rel = $f.FullName.Substring($srcFull.Length).TrimStart('\')
    if ($never -contains $rel) { continue }
    if ($rel -like 'backup\*' -or $rel -like 'update_tmp\*') { continue }
    $dst = Join-Path $Root $rel
    $dstDir = Split-Path -Parent $dst
    if (-not (Test-Path -LiteralPath $dstDir)) { New-Item -ItemType Directory -Path $dstDir -Force | Out-Null }
    if (Test-Path -LiteralPath $dst -PathType Leaf) {
      $di = Get-Item -LiteralPath $dst
      if ($di.Length -eq $f.Length) {
        $h1 = (Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash
        $h2 = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
        if ($h1 -eq $h2) { continue }
      }
      $b = Join-Path $bak $rel
      $bd = Split-Path -Parent $b
      if (-not (Test-Path -LiteralPath $bd)) { New-Item -ItemType Directory -Path $bd -Force | Out-Null }
      Copy-Item -LiteralPath $dst -Destination $b -Force
      $changed.Add($rel)
    } else {
      $added.Add($rel)
    }
    Copy-Item -LiteralPath $f.FullName -Destination $dst -Force
  }
  L ('FILES_SWAPPED changed=' + $changed.Count + ' added=' + $added.Count)
} catch {
  $failed = $true
  L ('SWAP_FAILED ' + $_.Exception.Message)
  Restore-Files
}

# 3) start the server again; if the new version does not answer, roll back automatically
Stop-AhkamServers
Start-AhkamServer
if (-not (Wait-Health 25)) {
  L 'NEW_SERVER_NOT_RESPONDING - rolling back'
  Stop-AhkamServers
  Start-Sleep -Seconds 1
  if (-not $failed) { Restore-Files }
  Start-AhkamServer
  [void](Wait-Health 20)
  L 'ROLLED_BACK'
} else {
  L ('UPDATE_OK failed=' + $failed)
}

# 4) keep only the 3 most recent backups, clean staging
try {
  $bk = @(Get-ChildItem -LiteralPath (Join-Path $Root 'backup') -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
  for ($i = 3; $i -lt $bk.Count; $i++) { Remove-Item -LiteralPath $bk[$i].FullName -Recurse -Force -ErrorAction SilentlyContinue }
} catch { }
Start-Sleep -Seconds 2
try { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue } catch { }
