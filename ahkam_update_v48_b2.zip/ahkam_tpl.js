/* ahkam_tpl.js — قراءة كروكي AutoCAD حسب موضع الخلايا (قالب المكتب) — v52 (قراءة الحروف مباشرة من أرقام الرسم عبر ahkam_glyph.js، وOCR احتياطي فقط)
   الفكرة: العناوين («المالك»، «المنطقة»...) مرسومة كأشكال فلا تُقرأ، وبعض حروف القيم العربية يخرج مشوّهًا من الـPDF
   (خريطة الحروف في خط AutoCAD خاطئة)، لكن مواضع القيم سليمة. لذلك:
   1) نحدّد كل قيمة بموضعها في الصفحة (نسب مئوية من العرض/الارتفاع ⇒ تعمل مع أي مقاس A3/A1)
   2) الأرقام (رقم الطلب/السجل/التاريخ) تُؤخذ من نص الـPDF لأنها سليمة
   3) المنطقة/المدينة/الاستخدام: أقرب اسم معروف لقراءة OCR وللنص المشوّه معًا
   4) الاسم والحي: OCR على صورة الخلية نفسها (سطر واحد) بدل مسح الصفحة كلها */
(function(root){
'use strict';
const ZONES=[
 {k:'رقم الطلب',y:0.0672,x0:0.740,x1:0.810,type:'req'},
 {k:'المنطقة',y:0.0903,x0:0.830,x1:0.935,type:'region'},
 {k:'المدينة',y:0.1097,x0:0.830,x1:0.935,type:'city'},
 {k:'الموقع',y:0.1335,x0:0.830,x1:0.935,type:'loc'},
 {k:'الاستخدام',y:0.1541,x0:0.830,x1:0.935,type:'use'},
 {k:'اسم المالك',y:0.1827,x0:0.800,x1:0.915,type:'name'},
 {k:'رقم السجل',y:0.1894,x0:0.735,x1:0.798,type:'id'},
 {k:'التاريخ',y:0.3568,x0:0.760,x1:0.825,type:'date'}
];
const TOL=0.0095;
const REGIONS=['مكة المكرمة','المدينة المنورة','الرياض','القصيم','المنطقة الشرقية','عسير','تبوك','حائل','الحدود الشمالية','جازان','نجران','الباحة','الجوف'];
const CITIES=['جدة','مكة المكرمة','الطائف','الرياض','المدينة المنورة','الدمام','الخبر','الظهران','الأحساء','بريدة','عنيزة','تبوك','حائل','أبها','خميس مشيط','جازان','نجران','الباحة','سكاكا','عرعر','ينبع','القنفذة','الليث','رابغ','الجموم','خليص','بحرة','أضم','الكامل','حفر الباطن','الجبيل','القطيف','الخرج','المجمعة','الزلفي','الدوادمي','بيشة','محايل','صبيا','شرورة','القريات','الوجه','ضباء','أملج','العلا','بدر','خيبر','المهد','الدرعية','المزاحمية','الدلم','وادي الدواسر','رنية','تربة','الخرمة','ظهران الجنوب','أبو عريش','صامطة','النماص','بلجرشي'];
const DISTRICTS=['الشاطئ','الحمراء','الروضة','السلامة','الصفا','النعيم','الزهراء','الفيحاء','الرحاب','المروة','الأندلس','الشرفية','البغدادية الغربية','البغدادية الشرقية','الكندرة','الهنداوية','غليل','الفيصلية','الربوة','الخالدية','النزهة','الحمدانية','المحمدية','أبحر الشمالية','أبحر الجنوبية','الصواري','الياقوت','اللؤلؤ','الشراع','المرجان','الفنار','الأجاويد','البوادي','النسيم','العزيزية','الجامعة','مشرفة','الرويس','البلد','الواحة','الورود','السليمانية','الصحيفة','الثعالبة','القريات','مدائن الفهد','الحرمين','بريمان','النهضة','بني مالك','الأمير فواز','الجوهرة','الوزيرية','التيسير','الصفوة','الشاطئ','الريان','الرحمانية','الناصرية','الحزام الذهبي','المنار','الصالحية','الخمرة','الكيلو 14','الكيلو 7','الكيلو 10','ذهبان','الطيبة','الفروسية','الأمير سلطان','السامر','الشلال','الرغامة','الصناعية','الصناعية الجديدة','مهزور','النخيل','الحي الصناعي','الأجواد','الوفاء','الازدهار','المنتزهات','الساحل','الروابي','الرمال','الخليج','الشراع','البساتين','الأمانة','الإسكان','التعاون','الرحاب','الجامعة','العدل','النوارس','طيبة','الواحة']; 
const USES=['سكني','تجاري','سكني تجاري','زراعي','صناعي'];
const nk=s=>root.AhkamPdf.nk(s);
function lev(a,b){const m=a.length,n=b.length;if(!m)return n;if(!n)return m;let p=[...Array(n+1).keys()];
  for(let i=1;i<=m;i++){const c=[i];for(let j=1;j<=n;j++)c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));p=c}return p[n]}
/* أقرب اسم في القائمة لأي من المرشحين؛ يُقبل إن كان الفرق صغيرًا نسبةً لطول الاسم */
function snap(cands,list){
  let best=null;
  for(const c0 of cands){const c=nk(c0||'');if(c.length<2)continue;
    for(const name of list){const t=nk(name);
      let d=lev(c,t);
      if(t.startsWith(c)&&c.length>=3)d=Math.min(d,1);          // «مكة» ⇒ «مكة المكرمة»
      const lim=Math.max(1,Math.floor(t.length/4));
      if(d<=lim&&(!best||d<best.d))best={name,d}}}
  return best;
}
/* تحديد قيم كل حقل من عناصر النص. العناصر: {s,cx,cy,x,y,w,h} حيث cx/cy نسب من الصفحة (cy من الأعلى) */
/* مراجعة ثانية مستقلة: الكلمة المشوّهة في الملف تحتفظ غالبًا بعدد حروفها وبعضها في مواضعها */
function arOnly(t){return root.AhkamPdf.clean(t||'').replace(/[^\u0600-\u06FF]/g,'')}
function cons(a,g){const x=nk(a).replace(/\s/g,''),y=nk(g).replace(/\s/g,'');if(!x||x.length!==y.length)return false;let m=0;for(let i=0;i<x.length;i++)if(x[i]===y[i])m++;return m/x.length>=0.5}
/* A,B: قراءتان للكلمة بإعدادين مختلفين؛ g: نص الكلمة المشوّه من الـPDF */
function pickWord(A,B,g){
  const a=A||'',b=B||'';
  if(!a&&!b)return {w:'',c:0};
  if(a&&b&&nk(a)===nk(b)&&cons(a,g))return {w:a,c:0.92};
  const ca=a&&cons(a,g),cb=b&&cons(b,g);
  if(ca&&cb)return {w:lev(nk(a),nk(g))<=lev(nk(b),nk(g))?a:b,c:0.72};
  if(ca)return {w:a,c:0.72};
  if(cb)return {w:b,c:0.72};
  return {w:a||b,c:0.5};
}
function assign(items){
  const out={};
  for(const z of ZONES){
    const its=items.filter(i=>Math.abs(i.cy-z.y)<=TOL&&i.cx>=z.x0&&i.cx<=z.x1);
    if(its.length)out[z.k]={zone:z,items:its.sort((a,b)=>b.x-a.x)};
  }
  return out;
}
async function cropOcr(page,H,its,psm,px){
  const h=Math.max(...its.map(i=>i.h)),x0=Math.min(...its.map(i=>i.x))-h*0.5,x1=Math.max(...its.map(i=>i.x+i.w))+h*0.5;
  const yb=Math.min(...its.map(i=>i.y))-h*0.45,yt=Math.max(...its.map(i=>i.y))+h*1.1;
  const scale=Math.max(2,Math.min(8,(px||70)/h));
  const vp=page.getViewport({scale});
  const px0=Math.floor(x0*scale),py0=Math.floor((H-yt)*scale),pw=Math.ceil((x1-x0)*scale),ph=Math.ceil((yt-yb)*scale);
  const pad=24,cv=document.createElement('canvas');cv.width=pw+pad*2;cv.height=ph+pad*2;
  const cx=cv.getContext('2d',{willReadFrequently:true});cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);
  const tmp=document.createElement('canvas');tmp.width=pw;tmp.height=ph;
  const tx=tmp.getContext('2d',{willReadFrequently:true});tx.fillStyle='#fff';tx.fillRect(0,0,pw,ph);
  await page.render({canvasContext:tx,viewport:vp,transform:[1,0,0,1,-px0,-py0]}).promise;
  cx.drawImage(tmp,pad,pad);
  const im=cx.getImageData(0,0,cv.width,cv.height),d=im.data;
  for(let i=0;i<d.length;i+=4){const l=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2],v=l<150?0:255;d[i]=d[i+1]=d[i+2]=v}
  cx.putImageData(im,0,0);
  const r=await root.AhkamOcr.ocrLine(cv,psm||7);
  return r.text;
}
async function readPdf(lib,buf,say){
  const pdf=await lib.getDocument({data:new Uint8Array(buf)}).promise;
  const page=await pdf.getPage(1),vp=page.getViewport({scale:1}),W=vp.width,H=vp.height;
  const tc=await page.getTextContent(),items=[];
  for(const it of tc.items){
    if(typeof it.str!=='string'||!it.str.trim())continue;
    const tr=it.transform,h=Math.abs(it.height)||Math.hypot(tr[2],tr[3])||8,w=it.width||0;
    items.push({s:it.str,x:tr[4],y:tr[5],w,h,cx:(tr[4]+w/2)/W,cy:(H-(tr[5]+h*0.3))/H});
  }
  const zones=assign(items),fields={};
  /* v52: النص الصحيح من أرقام الحروف المرسومة (لا يتأثر بجدول الترميز الخاطئ) */
  let gruns=[],gz={},glyphUsed=false;
  if(root.AhkamGlyph){
    try{
      gruns=(await root.AhkamGlyph.readRuns(lib,page)).filter(r=>r.dec).map(r=>Object.assign(r,{cx:(r.x+r.w/2)/W,cy:(H-(r.y+r.h*0.3))/H}));
      for(const z of ZONES){
        const rs=gruns.filter(r=>Math.abs(r.cy-z.y)<=TOL&&r.cx>=z.x0&&r.cx<=z.x1);
        if(rs.length)gz[z.k]=root.AhkamGlyph.joinRuns(rs);
      }
    }catch(e){console.error('glyph',e)}
  }
  const put=(k,v,conf,how)=>{if(v)fields[k]={value:v,conf,how,page:1,label:'موضع في القالب'}};
  const ocrOk=root.AhkamOcr&&await root.AhkamOcr.ocrReady();
  const runFor=it=>gruns.find(r=>Math.abs(r.y-it.y)<=Math.max(2,it.h*0.6)&&(r.x+r.w/2)>=it.x-2&&(r.x+r.w/2)<=it.x+it.w+2&&/[^\s]/.test(r.dec.text));
  const patOk=(pat,c)=>{const a=nk(pat||''),b=nk(c||'');if(!a||a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(a[i]!=='\u0000'&&a[i]!==b[i])return false;return a.replace(/\u0000/g,'').length>=Math.ceil(a.length/2)};
  /* كلمة فيها حروف غير معروفة: نقبل قراءة OCR فقط إن طابقت كل الحروف المعروفة في مواضعها */
  const pickGlyph=(A,B,g,it)=>{
    const r=runFor(it);if(!r||!r.dec.unknown)return null;
    const okA=A&&patOk(r.dec.text,A),okB=B&&patOk(r.dec.text,B);
    if(okA&&okB&&nk(A)===nk(B))return {w:A,c:0.95};
    if(okA)return {w:A,c:0.9};
    if(okB)return {w:B,c:0.9};
    return null;
  };
  /* قراءة مباشرة بلا OCR حين تكون كل حروف الحقل معروفة */
  let glyphInferred=false;
  const glyphFirst=async(zone,k,its)=>{
    const G=gz[k];
    if(!G||!G.complete||!['name','loc','region','city','use'].includes(zone.type))return false;
    const txt=G.text,inf=G.inferred>0;
    if(zone.type==='region'||zone.type==='city'||zone.type==='use'){
      const list=zone.type==='region'?REGIONS:zone.type==='city'?CITIES:USES;
      const s=snap([txt],list);
      if(s&&s.d===0)put(k,s.name,inf?0.95:0.98,'حروف الملف');
      else if(s)put(k,s.name,0.86,'حروف الملف + أقرب اسم معروف');
      else put(k,txt,0.88,'حروف الملف');
    }else if(zone.type==='loc'){
      let ws=txt.split(' ').filter(Boolean);
      if(ws.length>1&&nk(ws[0])==='حي')ws=ws.slice(1);
      const v=ws.join(' '),s=snap([v],DISTRICTS);
      if(s&&s.d===0)put(k,s.name,inf?0.95:0.98,'حروف الملف');
      else put(k,v,inf?0.9:0.95,'حروف الملف');
    }else put(k,txt,inf?0.9:0.98,'حروف الملف');
    /* حروف مستنتجة من ترتيب الخط (ن ق ف ...): نؤكدها بقراءة OCR مستقلة إن وُجدت، وإلا ننبّه المستخدم */
    if(inf&&(zone.type==='name'||zone.type==='loc')&&fields[k]){
      let agree=null;
      if(ocrOk){
        try{
          const ws=[];
          for(const it of its){
            const A=arOnly(await cropOcr(page,H,[it],8,70)),B=arOnly(await cropOcr(page,H,[it],7,110));
            ws.push(patOk(runFor(it)?runFor(it).dec.text:'',A)?A:B);
          }
          const a=nk(ws.join('')),b=nk(txt.replace(/\s/g,''));
          agree=lev(a,b)<=Math.floor(b.length/8);
        }catch(e){console.error(e)}
      }
      if(agree===true)fields[k].conf=0.97,fields[k].how='حروف الملف + تأكيد OCR';
      else if(agree===false)fields[k].conf=0.78,fields[k].how='حروف الملف (خالف OCR — راجِع)';
      else glyphInferred=true;
    }
    glyphUsed=true;return true;
  };
  let needOcr=false;
  for(const k in zones){
    const {zone,items:its}=zones[k],raw=its.map(i=>root.AhkamPdf.clean(i.s)).join(' ');
    if(await glyphFirst(zone,k,its))continue;
    const gtxt=gz[k]&&gz[k].complete?gz[k].text.replace(/\s/g,''):'';
    if(zone.type==='req'){const m=raw.match(/\d{5,}/);put(k,m&&m[0],m&&gtxt.includes(m[0])?0.98:0.9,'نص PDF')}
    else if(zone.type==='id'){const m=raw.match(/(?<!\d)[12]\d{9}(?!\d)/);put(k,m&&m[0],m&&gtxt.includes(m[0])?0.98:0.9,'نص PDF')}
    else if(zone.type==='date'){const h=root.AhkamPdf.parseHijri(raw),hg=gtxt?root.AhkamPdf.parseHijri(gtxt):null;
      put(k,h&&h.d+'/'+h.m+'/'+h.y,h&&hg&&hg.d===h.d&&hg.m===h.m&&hg.y===h.y?0.98:0.85,'نص PDF')}
    else{
      const words=[];let minc=1;
      for(const it of its){
        const g=root.AhkamPdf.clean(it.s);let A='',B='';
        if(ocrOk){try{say&&say('قراءة «'+k+'» بصريًا (مراجعتان)...');A=arOnly(await cropOcr(page,H,[it],8,70));B=arOnly(await cropOcr(page,H,[it],7,110))}catch(e){console.error(e)}}
        const p=pickGlyph(A,B,g,it)||pickWord(A,B,g);words.push(p.w);minc=Math.min(minc,p.c);
      }
      let ocr=words.filter(Boolean).join(' ');
      const ocrA=ocr;
      if(zone.type==='region'||zone.type==='city'||zone.type==='use'){
        const list=zone.type==='region'?REGIONS:zone.type==='city'?CITIES:USES;
        const sa=snap([ocrA],list),sb=snap([raw],list);
        const b=(sa&&sb&&sa.name===sb.name)?sa:(sa||sb);
        if(b)put(k,b.name,(sa&&sb&&sa.name===sb.name)?0.92:(sa&&sa.d===0?0.88:0.75),'مراجعة مزدوجة');
      }else if(ocr){
        let ws=ocr.split(' ');
        if(zone.type==='loc'&&ws.length>1&&nk(ws[0])==='حي')ws=ws.slice(1);
        let v=ws.join(' ');
        if(zone.type==='loc'){const b=snap([v],DISTRICTS);if(b&&b.d===0){put(k,b.name,0.92,'مراجعة مزدوجة');v=''}else if(b&&b.d<=1&&minc>=0.7){put(k,b.name,0.8,'أقرب حي معروف');v=''}}
        if(v&&v.length>=2)put(k,v,minc,'مراجعة مزدوجة');
      }else if(!ocrOk)needOcr=true;
    }
  }
  return {fields,pages:1,text:items.map(i=>i.s).join(' | '),hasText:true,viaTpl:true,viaGlyph:glyphUsed,glyphInferred,needOcr,arCount:999};
}
root.AhkamTpl={readPdf,assign,snap,ZONES,lev,pickWord,cons,REGIONS,CITIES,DISTRICTS,USES};
})(typeof window!=='undefined'?window:globalThis);
