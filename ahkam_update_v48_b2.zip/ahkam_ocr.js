/* ahkam_ocr.js — قراءة بصرية (OCR) لكروكي PDF الذي رُسم نصّه كأشكال/خطوط (v49)
   متى يُستعمل؟ عندما لا يحوي الـPDF نصًّا عربيًّا قابلًا للنسخ (مثل تصدير AutoCAD بخطوط SHX / نص محوَّل لخطوط).
   كيف يعمل؟ 1) يرسم الصفحة بدقة عالية ويثنّيها (أبيض/أسود) لإزالة ألوان الخلفيات
            2) tesseract.js محلي (عربي+إنجليزي) يعيد كل كلمة مع إحداثياتها
            3) الكلمات تُحوَّل إلى نفس بنية نص pdf.js، فيعيد المحلّل الذكي في ahkam_pdf.js استعمال منطقه كاملًا
               (عناوين/قيم، جدول، قيمة تحت العنوان، تاريخ هجري، أرقام هندية...) دون أي افتراض لتخطيط ثابت
            4) إن لم تكفِ القراءة الأولى تُعاد الصفحة مقسَّمة إلى 4 مربعات بدقة أعلى، وتُدمج أفضل نتيجة لكل حقل.
   يعمل دون إنترنت بعد تشغيل SETUP_OCR.cmd مرة واحدة. */
(function(root){
'use strict';
const BASE='/ocr';
let worker=null,loading=null,progCb=null;
const say=m=>{try{progCb&&progCb(m)}catch(e){}};

function loadScript(src){
  return new Promise((res,rej)=>{
    if(root.Tesseract)return res();
    const s=document.createElement('script');s.src=src;
    s.onload=res;s.onerror=()=>rej(new Error('ERR_OCR_MISSING'));
    document.head.appendChild(s);
  });
}
async function ocrReady(){
  try{const r=await fetch(BASE+'/ready.txt?t='+Date.now());return r.ok}catch(e){return false}
}
async function getWorker(){
  if(worker)return worker;
  if(loading)return loading;
  loading=(async()=>{
    if(!(await ocrReady()))throw new Error('ERR_OCR_MISSING');
    await loadScript(BASE+'/tesseract.min.js');
    say('تحميل محرك OCR (مرة واحدة)...');
    const w=await root.Tesseract.createWorker('ara+eng',1,{
      workerPath:BASE+'/worker.min.js',corePath:BASE,langPath:BASE+'/lang',
      gzip:false,workerBlobURL:false,
      logger:m=>{if(m&&m.status==='recognizing text')say('قراءة النص بصريًا... '+Math.round((m.progress||0)*100)+'%')}
    });
    await w.setParameters({preserve_interword_spaces:'1',user_defined_dpi:'300'});
    worker=w;return w;
  })();
  try{return await loading}finally{loading=null}
}

/* رسم الصفحة ثم تثنية الألوان: الحبر الملوّن (أحمر/أزرق/أسود) يصبح أسود، وتعبئات الخلفية الفاتحة تصبح بيضاء */
async function renderPage(page,scale){
  const vp=page.getViewport({scale});
  const cv=document.createElement('canvas');cv.width=Math.ceil(vp.width);cv.height=Math.ceil(vp.height);
  const cx=cv.getContext('2d',{willReadFrequently:true});
  cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);
  await page.render({canvasContext:cx,viewport:vp}).promise;
  return cv;
}
function binarize(cv){
  const cx=cv.getContext('2d',{willReadFrequently:true});
  const im=cx.getImageData(0,0,cv.width,cv.height),d=im.data;
  for(let i=0;i<d.length;i+=4){
    const l=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];
    const v=l<150?0:255;d[i]=d[i+1]=d[i+2]=v;d[i+3]=255;
  }
  cx.putImageData(im,0,0);return cv;
}
function cropCanvas(src,x,y,w,h){
  const c=document.createElement('canvas');c.width=w;c.height=h;
  const cx=c.getContext('2d',{willReadFrequently:true});
  cx.drawImage(src,x,y,w,h,0,0,w,h);return c;
}

/* كلمات tesseract ⇒ عناصر بنفس شكل عناصر pdf.js (إحداثيات PDF: y لأعلى) */
function wordsOf(data){
  if(Array.isArray(data.words)&&data.words.length)return data.words;
  const out=[];
  for(const b of data.blocks||[])for(const p of b.paragraphs||[])for(const l of p.lines||[])for(const w of l.words||[])out.push(w);
  return out;
}
async function ocrCanvas(cv,scale,pageH,offX,offY,psm){
  const w=await getWorker();
  await w.setParameters({tessedit_pageseg_mode:String(psm||11)});
  let r;
  try{r=await w.recognize(cv,{},{blocks:true})}catch(e){r=await w.recognize(cv)}
  const items=[];
  for(const wd of wordsOf(r.data)){
    const t=String(wd.text||'').trim();if(!t||(wd.confidence!=null&&wd.confidence<25))continue;
    const b=wd.bbox;if(!b)continue;
    const x0=(b.x0+offX)/scale,x1=(b.x1+offX)/scale,y0=(b.y0+offY)/scale,y1=(b.y1+offY)/scale;
    items.push({s:t,x:x0,y:pageH-y1,w:x1-x0,h:Math.max(2,y1-y0),dir:'ltr',conf:wd.confidence||0});
  }
  return items;
}
function mergeItems(base,extra){
  const out=base.slice();
  for(const e of extra){
    const dup=out.some(o=>o.s===e.s&&Math.abs(o.x-e.x)<Math.max(3,.6*e.h)&&Math.abs(o.y-e.y)<Math.max(3,.6*e.h));
    if(!dup)out.push(e);
  }
  return out;
}
const KEYS=['رقم الطلب','اسم المالك','رقم السجل','الاستخدام','المنطقة','المدينة','الموقع','التاريخ','المساحة حسب الصك'];
const goodCount=f=>KEYS.filter(k=>f[k]&&f[k].conf>=0.65).length;
function mergeFields(a,b){
  const f=Object.assign({},a||{});
  for(const k in (b||{}))if(!f[k]||b[k].conf>f[k].conf)f[k]=b[k];
  return f;
}
function parsePage(pn,w,h,items){
  return AhkamPdf.parseRows([{pn,w,h,items}],{modes:['normal']});
}

async function readPdf(lib,buf,onStatus){
  progCb=onStatus;
  const pdf=await lib.getDocument({data:new Uint8Array(buf)}).promise;
  const SCALE=3,HI=4;
  let allFields={},text='',pagesRead=0;
  for(let pn=1;pn<=Math.min(pdf.numPages,2);pn++){
    const page=await pdf.getPage(pn),vp1=page.getViewport({scale:1});
    say('رسم الصفحة '+pn+' بدقة عالية...');
    const cv=binarize(await renderPage(page,SCALE));
    let items=await ocrCanvas(cv,SCALE,vp1.height,0,0,11);
    let r=parsePage(pn,vp1.width,vp1.height,items);
    if(goodCount(r.fields)<7){
      say('تحسين القراءة: مسح الصفحة على 4 مربعات...');
      const big=await renderPage(page,HI);
      const W=big.width,H=big.height,ox=Math.round(W*.08),oy=Math.round(H*.08);
      const tw=Math.round(W/2+ox),th=Math.round(H/2+oy);
      let more=[];
      for(const [tx,ty] of [[W-tw,0],[0,0],[W-tw,H-th],[0,H-th]]){
        const t=binarize(cropCanvas(big,tx,ty,tw,th));
        more=mergeItems(more,await ocrCanvas(t,HI,vp1.height,tx,ty,11));
      }
      const r2=parsePage(pn,vp1.width,vp1.height,mergeItems(items,more));
      r2.fields=mergeFields(r.fields,r2.fields);
      if(goodCount(r2.fields)>=goodCount(r.fields))r=r2;else r.fields=mergeFields(r.fields,r2.fields);
    }
    allFields=mergeFields(allFields,r.fields);
    text+=(pagesRead?'\n--- صفحة ---\n':'')+r.text;pagesRead++;
  }
  // قيم OCR لا تُعتبر «ثقة عالية» أبدًا: يراجعها المستخدم قبل الاعتماد
  for(const k in allFields)allFields[k].conf=Math.min(allFields[k].conf,0.8);
  return {fields:allFields,pages:pdf.numPages,text,ocr:true};
}
const REG=['مكة المكرمة','المدينة المنورة','الرياض','القصيم','المنطقة الشرقية','عسير','تبوك','حائل','الحدود الشمالية','جازان','نجران','الباحة','الجوف'];
function snapRegion(f){
  const r=f['المنطقة'];if(!r)return;const v=AhkamPdf.nk(r.value);if(v.length<3)return;
  for(const n of REG){const t=AhkamPdf.nk(n);if(t===v||t.startsWith(v)||v.startsWith(t.slice(0,4))){r.value=n;return}}
}
function mergeResults(a,b){
  const out=Object.assign({},a);
  out.fields=mergeFields(a.fields,b.fields);snapRegion(out.fields);
  out.text='[OCR]\n'+b.text+(a.text?'\n\n[نص PDF]\n'+a.text:'');
  out.hasText=true;
  return out;
}
async function ocrLine(cv,psm){
  const w=await getWorker();
  await w.setParameters({tessedit_pageseg_mode:String(psm||7)});
  const r=await w.recognize(cv);
  return {text:String(r.data.text||'').replace(/\s+/g,' ').trim(),conf:r.data.confidence||0};
}
root.AhkamOcr={readPdf,mergeResults,ocrReady,ocrLine,setProgress:f=>{progCb=f}};
})(typeof window!=='undefined'?window:globalThis);
