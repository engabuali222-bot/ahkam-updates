@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PORT=8799"
set "URL=http://127.0.0.1:%PORT%/Ahkam_Tool.html"
set "HEALTH=http://127.0.0.1:%PORT%/health"
set "SHUTDOWN=http://127.0.0.1:%PORT%/shutdown"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "LOG=%~dp0ahkam_server.log"
set "ERRLOG=%~dp0ahkam_server_error.log"

if not exist "%~dp0server.ps1" (
  echo server.ps1 not found next to this file.
  echo Extract the whole ZIP first, then run START_AHKAM.cmd from the extracted folder.
  pause
  exit /b 1
)
if exist "%ERRLOG%" del /q "%ERRLOG%" >nul 2>&1

title Ahkam Tool v48

echo ================================================
echo   AHKAM TOOL v48
echo ================================================
echo.

echo Checking local server...
"%PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ok=$false; try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 '%HEALTH%'; $exp='%~dp0'.TrimEnd('\'); if($r.StatusCode -eq 200 -and $r.Content.StartsWith('OK|v48|'+$exp)){ $ok=$true } elseif($r.StatusCode -eq 200 -and $r.Content -like 'OK|*'){ try { $s=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 '%SHUTDOWN%'; Start-Sleep -Milliseconds 350 } catch {} } } catch {}; if($ok){ exit 0 } else { exit 1 }" >nul 2>&1
if %errorlevel%==0 goto OPEN

echo Stopping any old/hung Ahkam server...
"%PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'powershell.exe' -and $_.CommandLine -like '*server.ps1*' -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
timeout /t 1 /nobreak >nul

echo Starting local server...
"%PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p='%~dp0server.ps1'; $q=[string][char]34; try { Start-Process -FilePath '%PS%' -ArgumentList @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',($q+$p+$q),'-Port','%PORT%') -WorkingDirectory '%~dp0' -WindowStyle Hidden -RedirectStandardError '%ERRLOG%' | Out-Null; exit 0 } catch { Add-Content -LiteralPath '%LOG%' -Value ('LAUNCH_FAILED ' + $_.Exception.Message); exit 1 }" >nul 2>&1
if errorlevel 1 goto FAIL

for /l %%I in (1,1,20) do (
  timeout /t 1 /nobreak >nul
  "%PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
    "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 '%HEALTH%'; if($r.StatusCode -eq 200 -and $r.Content -like 'OK|v48*'){ exit 0 } } catch {} ; exit 1" >nul 2>&1
  if not errorlevel 1 goto OPEN
)


:FAIL
echo.
echo The local server did not start.
echo.
if exist "%LOG%" (
  echo ===== ahkam_server.log =====
  type "%LOG%"
  echo ============================
)

if exist "%ERRLOG%" (
  echo ===== ahkam_server_error.log =====
  type "%ERRLOG%"
  echo ==================================
)
echo Syntax check of server.ps1:
"%PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile('%~dp0server.ps1',[ref]$null,[ref]$e); if($e){ $e | ForEach-Object { '  line ' + $_.Extent.StartLineNumber + ': ' + $_.Message } } else { '  OK (no syntax errors)' }"
echo.
echo Automatic recovery: checking whether port %PORT% is occupied...
"%PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { $tcp=Test-NetConnection -ComputerName 127.0.0.1 -Port %PORT% -WarningAction SilentlyContinue; if($tcp.TcpTestSucceeded){ 'PORT_IN_USE' } else { 'PORT_FREE' } } catch { 'PORT_CHECK_FAILED' }"

echo.
pause
exit /b 1

:OPEN
start "" "%URL%"
echo.
echo Ahkam Tool is open in your browser.
echo Keep this window open while using the tool.
echo.
pause
