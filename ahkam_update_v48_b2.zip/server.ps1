﻿
# Ahkam Tool local server -- version 31.
# No Python. No cmd.exe. No console window. TcpListener (no admin URL reservation).
# CAD conversion order:
#   1) accoreconsole.exe   (AutoCAD headless core console - most reliable, no GUI)
#   2) ODAFileConverter    (free Open Design Alliance converter, no AutoCAD needed)

param([int]$Port = 8765)

$ErrorActionPreference = 'Stop'
$AHKAM_VERSION = 'v48'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$root = $PSScriptRoot
if (-not $root) { $root = Split-Path -Parent $MyInvocation.MyCommand.Path }
$log = Join-Path $root 'ahkam_server.log'

function Write-Log([string]$m) {
  try {
    Add-Content -LiteralPath $log -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding UTF8
  } catch { }
}

function Get-Mime([string]$path) {
  switch ([IO.Path]::GetExtension($path).ToLowerInvariant()) {
    '.html' { 'text/html; charset=utf-8' }
    '.htm'  { 'text/html; charset=utf-8' }
    '.js'   { 'application/javascript; charset=utf-8' }
    '.mjs'  { 'text/javascript; charset=utf-8' }
    '.pdf'  { 'application/pdf' }
    '.css'  { 'text/css; charset=utf-8' }
    '.json' { 'application/json; charset=utf-8' }
    '.svg'  { 'image/svg+xml' }
    '.png'  { 'image/png' }
    '.jpg'  { 'image/jpeg' }
    '.txt'  { 'text/plain; charset=utf-8' }
    '.wasm' { 'application/wasm' }
    '.dxf'  { 'application/dxf' }
    default { 'application/octet-stream' }
  }
}

function Read-FileShared([string]$path) {
  # v20.1: AutoCAD keeps the open DWG/DXF locked for writing, so [IO.File]::ReadAllBytes (which asks for
  # FileShare.Read) fails with a sharing violation -> "ERR_READ_FAILED". Open with full sharing instead,
  # retry briefly (AutoCAD may be mid-save), and finally fall back to copying the file first.
  $last = $null
  for ($try = 0; $try -lt 6; $try++) {
    $fs = $null
    try {
      $fs = New-Object System.IO.FileStream($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
      $len = [int]$fs.Length
      $buf = New-Object byte[] $len
      $off = 0
      while ($off -lt $len) { $n = $fs.Read($buf, $off, $len - $off); if ($n -le 0) { break }; $off += $n }
      return ,$buf
    } catch { $last = $_.Exception.Message; Start-Sleep -Milliseconds 250 }
    finally { if ($fs) { $fs.Dispose() } }
  }
  try {
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('ahkam_' + [Guid]::NewGuid().ToString('N') + [IO.Path]::GetExtension($path))
    Copy-Item -LiteralPath $path -Destination $tmp -Force -ErrorAction Stop
    try { return ,[IO.File]::ReadAllBytes($tmp) } finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
  } catch { $last = $last + ' | copy: ' + $_.Exception.Message }
  throw ('SHARED_READ_FAILED ' + $last)
}

function Send-Response($stream, [int]$status, [string]$statusText, [string]$contentType, [byte[]]$body) {
  if ($null -eq $body) { $body = New-Object byte[] 0 }
  $head = "HTTP/1.1 $status $statusText`r`n" +
          "Content-Type: $contentType`r`n" +
          "Content-Length: $($body.Length)`r`n" +
          "Cache-Control: no-store, no-cache, must-revalidate`r`n" +
          "Pragma: no-cache`r`n" +
          "Connection: close`r`n`r`n"
  $hb = [Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($hb, 0, $hb.Length)
  if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
  $stream.Flush()
}

function Send-Text($stream, [int]$status, [string]$statusText, [string]$text) {
  Send-Response $stream $status $statusText 'text/plain; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($text))
}

function Read-HeaderBlock($stream) {
  $buf = New-Object System.Collections.Generic.List[byte]
  $state = 0
  while ($true) {
    $b = $stream.ReadByte()
    if ($b -lt 0) { return $null }
    $buf.Add([byte]$b) | Out-Null
    if ($b -eq 13) { if ($state -eq 2) { $state = 3 } else { $state = 1 } }
    elseif ($b -eq 10) {
      if ($state -eq 3) { break }
      elseif ($state -eq 1) { $state = 2 }
      else { $state = 0 }
    }
    else { $state = 0 }
    if ($buf.Count -gt 65536) { return $null }
  }
  return [Text.Encoding]::ASCII.GetString($buf.ToArray())
}

function Read-Body($stream, [int]$length) {
  $data = New-Object byte[] $length
  $got = 0
  while ($got -lt $length) {
    $n = $stream.Read($data, $got, $length - $got)
    if ($n -le 0) { break }
    $got += $n
  }
  if ($got -ne $length) { throw "ERR_BODY_TRUNCATED" }
  return $data
}

function Send-Json($stream, [int]$status, [string]$statusText, [hashtable]$obj) {
  $json = $obj | ConvertTo-Json -Compress -Depth 12
  Send-Response $stream $status $statusText 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json))
}

function Get-QueryParam([string]$query, [string]$name) {
  if (-not $query) { return $null }
  foreach ($pair in $query -split '&') {
    if (-not $pair) { continue }
    $kv = $pair -split '=', 2
    if ($kv[0] -eq $name) {
      if ($kv.Count -gt 1) { return [Uri]::UnescapeDataString($kv[1]) } else { return '' }
    }
  }
  return $null
}

# ================= LICENSE: one device only (offline, signed) =================
# The license is signed by the seller private key and verified here with the public key below.
# It is bound to this computer Machine ID, so copying the folder to another PC does not work.
# LICENSE_PUBLIC_KEY_BEGIN
$LICENSE_PUBLIC_KEY_XML = '<RSAKeyValue><Modulus>rQIDnkhEXu2oWASzK7lH0ozoTWBU0/igmHV9ERzSduIHHK0sWW1fMHdeC1tbM4gIofYFKo1qGJD7NSZNnBe1Vx22XMu6BZ7EsxWuXuVEZvFqXSXTRp1wSC7ap77x+/XU400Bje0VHnlB+Jci3R8bJUwjj9pdPw56TS/nWgHsCf73vLOL1nQvIdyeFxwtrrNmbozxqzYHP17hhXuPisyMhdSPfUaR2VZIqHnX/h88LKNsbjxs7nln8iC+v+WE8ENYV42S3GAnng0LJBXcSQewQz/5BPTPH4qQsDbh1BueB5VkxAqco6C/799WIthfhqJ+ydgHawQHzu7pztah6mfyLw==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
# LICENSE_PUBLIC_KEY_END
# UPDATE_PUBLIC_KEY_BEGIN  (verifies the seller signature of update packages; the private key is never shipped)
$UPDATE_PUBLIC_KEY_XML = '<RSAKeyValue><Modulus>ouIJklfkPMtiFN1EDMt23AkwuFH9odNiwVd7gHSF8y1yijPVvrS2dugzii1wWKlD+n3zeEFFrw+Y7GLJ5/WgWFi3mBmvdBI6Eqmzyl4Oz2Lz9+j3FeCWW/3QtK/+WizRomtZ/8OjxYkemx3+RlRmT7KGgJA5sWsIFFoxCAQu+FtYWVeXs57y0GJHiWlUhlxSbPR+RWlQgeG52l81lwzY5CuNbZrm4jD3N9saqyitF8iDziUvg4A5/vDczEgK9mdjcoRxMzPTmXiJvBRwvidCEqjxjUe3w4qdm5Pv9qXERMqjc7De+E3OF94EgHBgS3OqRy9fbT/raq+1cHWqATwtJr4c5Bi4w+3LgDYso3oxYc57Vlq48rl1H40Z3exe1oh469pk3ItizUrSiHEU57N3GJEzZKqhS2R3mYx+uVMpZ6JVpdde3P/HDILLXTtE24swBdR0RGJ0d3D3tB5LQeSlUJZEEQjFD/uFQNTQqSgt1knLVGR3gaM/7yM4DK2nSoDv</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
# UPDATE_PUBLIC_KEY_END
$script:Licensed = $false
$script:LicReason = 'no_license'
$script:LicName = ''
$script:LicExp = ''
$script:MachineId = ''

function ConvertFrom-B64Url([string]$s) {
  $s = $s.Replace('-', '+').Replace('_', '/')
  while ($s.Length % 4 -ne 0) { $s += '=' }
  return ,([Convert]::FromBase64String($s))
}

function Get-MachineId {
  $parts = New-Object System.Collections.Generic.List[string]
  try { $parts.Add([string](Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid -ErrorAction Stop).MachineGuid) } catch { $parts.Add('noguid') }
  try { $parts.Add([string](Get-CimInstance -ClassName Win32_BaseBoard -ErrorAction Stop | Select-Object -First 1).SerialNumber) } catch { $parts.Add('nobb') }
  try { $parts.Add([string](Get-CimInstance -ClassName Win32_Processor -ErrorAction Stop | Select-Object -First 1).ProcessorId) } catch { $parts.Add('nocpu') }
  $raw = ($parts.ToArray() -join '|').ToUpperInvariant()
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $h = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes('AHKAM-ID-1|' + $raw))
  $hex = (($h | ForEach-Object { $_.ToString('X2') }) -join '').Substring(0, 20)
  return ($hex.Substring(0,4) + '-' + $hex.Substring(4,4) + '-' + $hex.Substring(8,4) + '-' + $hex.Substring(12,4) + '-' + $hex.Substring(16,4))
}

function Set-LicenseState([bool]$ok, [string]$reason, [string]$name, [string]$exp) {
  $script:Licensed = $ok
  $script:LicReason = $reason
  $script:LicName = $name
  $script:LicExp = $exp
}

function Test-LicenseText([string]$text) {
  # Returns $true and fills the state when the license is genuine, unexpired and made for this PC.
  try {
    $t = ([string]$text) -replace '\s', ''
    $dot = $t.IndexOf('.')
    if ($dot -lt 1) { Set-LicenseState $false 'bad_format' '' ''; return $false }
    $payload = ConvertFrom-B64Url ($t.Substring(0, $dot))
    $sig = ConvertFrom-B64Url ($t.Substring($dot + 1))
    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    $rsa.FromXmlString($LICENSE_PUBLIC_KEY_XML)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hash = $sha.ComputeHash($payload)
    $oid = [System.Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256')
    if (-not $rsa.VerifyHash($hash, $oid, $sig)) { Set-LicenseState $false 'bad_signature' '' ''; return $false }
    $obj = [Text.Encoding]::UTF8.GetString($payload) | ConvertFrom-Json
    if ([string]$obj.p -ne 'AHKAM') { Set-LicenseState $false 'bad_product' '' ''; return $false }
    if (([string]$obj.mid).ToUpperInvariant() -ne $script:MachineId) { Set-LicenseState $false 'other_device' '' ''; return $false }
    $exp = [string]$obj.exp
    if ($exp) {
      $d = [datetime]::ParseExact($exp, 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
      if ((Get-Date).Date -gt $d.Date) { Set-LicenseState $false 'expired' ([string]$obj.name) $exp; return $false }
    }
    Set-LicenseState $true 'ok' ([string]$obj.name) $exp
    return $true
  } catch {
    Write-Log ('LICENSE_CHECK_ERROR ' + $_.Exception.Message)
    Set-LicenseState $false 'error' '' ''
    return $false
  }
}

function Initialize-License {
  $script:MachineId = Get-MachineId
  $lf = Join-Path $root 'license.key'
  if (Test-Path -LiteralPath $lf -PathType Leaf) {
    $txt = [IO.File]::ReadAllText($lf, [Text.Encoding]::UTF8)
    $null = Test-LicenseText $txt
  } else {
    Set-LicenseState $false 'no_license' '' ''
  }
  Write-Log ('LICENSE_STATE ' + $script:LicReason + ' id=' + $script:MachineId)
}
# ================= END LICENSE =================

# Native Windows Open File dialog (WinForms), run on its own real STA runspace so it
# never touches the main listener thread/runspace while the dialog is shown.
function Show-NativeOpenFileDialog([string]$Filter, [string]$Title) {
  $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
  $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
  $rs.ApartmentState = [System.Threading.ApartmentState]::STA
  $rs.ThreadOptions = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
  $rs.Open()
  $ps = [System.Management.Automation.PowerShell]::Create()
  $ps.Runspace = $rs
  [void]$ps.AddScript({
    param($f, $t)
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = $f
    $dlg.Title = $t
    $dlg.Multiselect = $false
    $dlg.CheckFileExists = $true
    $dlg.RestoreDirectory = $true
    $owner = New-Object System.Windows.Forms.Form
    $owner.TopMost = $true
    $res = $dlg.ShowDialog($owner)
    $owner.Dispose()
    if ($res -eq [System.Windows.Forms.DialogResult]::OK) { $dlg.FileName } else { $null }
  }).AddArgument($Filter).AddArgument($Title) | Out-Null
  $out = $ps.Invoke()
  $hadErr = $ps.Streams.Error.Count -gt 0
  $errMsg = if ($hadErr) { $ps.Streams.Error[0].ToString() } else { '' }
  $ps.Dispose(); $rs.Close(); $rs.Dispose()
  if ($hadErr) { throw $errMsg }
  if ($out -and $out.Count -gt 0) { return [string]$out[0] } else { return $null }
}

# ---- v19: non-blocking native Open File dialog -------------------------------------
# The dialog runs on its own STA runspace via BeginInvoke, so the HTTP loop stays free
# (the page polls /pick-cad-poll). The hidden owner form is forced to the foreground,
# otherwise Windows often opens the dialog BEHIND the browser and the button looks dead.
$script:PickJobs = @{}

function Start-NativeOpenFileDialogJob([string]$Filter, [string]$Title) {
  foreach ($k in @($script:PickJobs.Keys)) {
    $j0 = $script:PickJobs[$k]
    if ($j0 -and -not $j0.handle.IsCompleted -and ((Get-Date) - $j0.started).TotalMinutes -lt 10) { return [string]$k }
  }
  $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
  $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
  $rs.ApartmentState = [System.Threading.ApartmentState]::STA
  $rs.ThreadOptions = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
  $rs.Open()
  $ps = [System.Management.Automation.PowerShell]::Create()
  $ps.Runspace = $rs
  [void]$ps.AddScript({
    param($f, $t)
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    Add-Type -AssemblyName System.Drawing | Out-Null
    try {
      if (-not ('Ahkam.Win' -as [type])) {
        Add-Type -Namespace Ahkam -Name Win -MemberDefinition '[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetForegroundWindow(System.IntPtr h); [System.Runtime.InteropServices.DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, System.UIntPtr extra);'
      }
    } catch { }
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = $f
    $dlg.Title = $t
    $dlg.Multiselect = $false
    $dlg.CheckFileExists = $true
    $dlg.RestoreDirectory = $true
    $owner = New-Object System.Windows.Forms.Form
    $owner.TopMost = $true
    $owner.ShowInTaskbar = $false
    $owner.FormBorderStyle = 'None'
    $owner.Opacity = 0
    $owner.StartPosition = 'CenterScreen'
    $owner.Size = New-Object System.Drawing.Size(1, 1)
    try { [Ahkam.Win]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero); [Ahkam.Win]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero) } catch { }
    $owner.Show()
    try { [void][Ahkam.Win]::SetForegroundWindow($owner.Handle) } catch { }
    $owner.Activate()
    $res = $dlg.ShowDialog($owner)
    $owner.Dispose()
    if ($res -eq [System.Windows.Forms.DialogResult]::OK) { $dlg.FileName } else { $null }
  })
  [void]$ps.AddArgument($Filter)
  [void]$ps.AddArgument($Title)
  $handle = $ps.BeginInvoke()
  $id = [guid]::NewGuid().ToString('N')
  $script:PickJobs[$id] = @{ ps = $ps; rs = $rs; handle = $handle; started = (Get-Date) }
  return $id
}

function Get-NativeDialogJobResult([string]$Id) {
  $j = $script:PickJobs[$Id]
  if (-not $j) { return @{ ok = $false } }
  if (-not $j.handle.IsCompleted) { return @{ ok = $true; done = $false } }
  $out = $null
  $err = ''
  try { $out = $j.ps.EndInvoke($j.handle) } catch { $err = $_.Exception.Message }
  if (-not $err -and $j.ps.Streams.Error.Count -gt 0) { $err = $j.ps.Streams.Error[0].ToString() }
  try { $j.ps.Dispose(); $j.rs.Close(); $j.rs.Dispose() } catch { }
  $script:PickJobs.Remove($Id)
  if ($err) { Write-Log ('PICK_CAD_JOB_FAILED ' + $err); return @{ ok = $false; error = 'ERR_PICK_FAILED' } }
  if ($out -and $out.Count -gt 0 -and $out[0]) { return @{ ok = $true; done = $true; path = [string]$out[0] } }
  return @{ ok = $true; done = $true; cancelled = $true }
}

# Native Windows folder-browse dialog (WinForms), same isolated-STA-runspace approach as
# Show-NativeOpenFileDialog above. RootFolder=Desktop so the tree includes "This PC" and
# every drive letter, letting the user navigate to any folder on any disk.
function Show-NativeFolderDialog([string]$Title, [string]$InitialPath) {
  $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
  $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
  $rs.ApartmentState = [System.Threading.ApartmentState]::STA
  $rs.ThreadOptions = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
  $rs.Open()
  $ps = [System.Management.Automation.PowerShell]::Create()
  $ps.Runspace = $rs
  [void]$ps.AddScript({
    param($t, $init)
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $t
    $dlg.ShowNewFolderButton = $true
    $dlg.RootFolder = [System.Environment+SpecialFolder]::Desktop
    if ($init -and (Test-Path -LiteralPath $init -PathType Container)) { $dlg.SelectedPath = $init }
    $owner = New-Object System.Windows.Forms.Form
    $owner.TopMost = $true
    $res = $dlg.ShowDialog($owner)
    $owner.Dispose()
    if ($res -eq [System.Windows.Forms.DialogResult]::OK) { $dlg.SelectedPath } else { $null }
  }).AddArgument($Title).AddArgument($InitialPath) | Out-Null
  $out = $ps.Invoke()
  $hadErr = $ps.Streams.Error.Count -gt 0
  $errMsg = if ($hadErr) { $ps.Streams.Error[0].ToString() } else { '' }
  $ps.Dispose(); $rs.Close(); $rs.Dispose()
  if ($hadErr) { throw $errMsg }
  if ($out -and $out.Count -gt 0) { return [string]$out[0] } else { return $null }
}


$script:AcadObj = $null
$script:AcadScanAt = $null
$script:AcadProgIds = @()
function Get-RunningAutoCAD {
  # v20: reuse the COM object between polls; the old version enumerated all of HKEY_CLASSES_ROOT
  # on EVERY 1-second poll, which froze the single-threaded server and made live refresh lag/time out.
  if($script:AcadObj){
    try { $null = $script:AcadObj.ActiveDocument.Name; return $script:AcadObj } catch { $script:AcadObj = $null }
  }
  try {
    $acad=[Runtime.InteropServices.Marshal]::GetActiveObject('AutoCAD.Application')
    if($acad){ $script:AcadObj=$acad; return $acad }
  } catch { }
  # slow path: versioned ProgIDs (e.g. AutoCAD.Application.25.1); scan the registry at most every 15 s
  if((-not $script:AcadScanAt) -or (((Get-Date) - $script:AcadScanAt).TotalSeconds -gt 15)){
    $script:AcadScanAt = Get-Date
    try {
      $script:AcadProgIds = @([Microsoft.Win32.Registry]::ClassesRoot.GetSubKeyNames() |
        Where-Object { $_ -like 'AutoCAD.Application.*' } | Sort-Object -Descending)
    } catch { $script:AcadProgIds = @() }
  }
  foreach($id in $script:AcadProgIds){
    try {
      $acad=[Runtime.InteropServices.Marshal]::GetActiveObject($id)
      if($acad){ $script:AcadObj=$acad; return $acad }
    } catch { }
  }
  return $null
}
function Get-AcadUnitsCode($doc){
  try { return [int]$doc.GetVariable('INSUNITS') } catch { return 0 }
}
function Add-AcadPolylineFeature([System.Collections.IList]$features,$ent,[string]$source='ModelSpace'){
  try {
    $name = [string]$ent.ObjectName
    if($name -notmatch 'Polyline$' -and $name -notin @('AcDbPolyline','AcDb2dPolyline','AcDb3dPolyline')){ return }
    if(-not [bool]$ent.Closed){ return }
    $c=@($ent.Coordinates)
    if($c.Count -lt 6){ return }
    $pts=New-Object System.Collections.Generic.List[object]
    if(($c.Count % 2) -eq 0){
      for($i=0;$i -lt $c.Count;$i+=2){ $pts.Add(@([double]$c[$i],[double]$c[$i+1])) | Out-Null }
    } elseif(($c.Count % 3) -eq 0){
      for($i=0;$i -lt $c.Count;$i+=3){ $pts.Add(@([double]$c[$i],[double]$c[$i+1])) | Out-Null }
    }
    if($pts.Count -lt 3){ return }
    $ring=New-Object System.Collections.Generic.List[object]
    foreach($p in $pts){$ring.Add($p)|Out-Null}
    if(($ring[0][0] -ne $ring[$ring.Count-1][0]) -or ($ring[0][1] -ne $ring[$ring.Count-1][1])){$ring.Add(@($ring[0][0],$ring[0][1]))|Out-Null}
    if($ring.Count -lt 4){return}
    $handle='';$layer='0'
    try{$handle=[string]$ent.Handle}catch{}
    try{$layer=[string]$ent.Layer}catch{}
    $sourceId=([string]$source)+'|'+$handle+'|'+$layer
    $bulges=New-Object System.Collections.Generic.List[double]
    for($bi=0;$bi -lt $pts.Count;$bi++){try{$bulges.Add([double]$ent.GetBulge($bi))|Out-Null}catch{$bulges.Add(0.0)|Out-Null}}
    $features.Add(@{type='Feature';properties=@{handle=$handle;layer=$layer;source=$source;sourceId=$sourceId;__ahkamSourceIds=@($sourceId);__ahkamBulges=@($bulges.ToArray())};geometry=@{type='Polygon';coordinates=@(,($ring.ToArray()))}})|Out-Null
  } catch { }
}
function Add-AcadProtectionSegments([System.Collections.IList]$segments,$ent,[string]$source='ModelSpace'){
  # Open roads, neighboring boundaries, and actual curved polyline segments are safety guards.
  # Bulged arcs are tessellated only for intersection/distance checks; the original CAD entity is untouched.
  try {
    $name=[string]$ent.ObjectName
    $handle='';$layer='0'
    try{$handle=[string]$ent.Handle}catch{}
    try{$layer=[string]$ent.Layer}catch{}
    $sourceId=([string]$source)+'|'+$handle+'|'+$layer
    if($name -eq 'AcDbLine'){
      $st=@($ent.StartPoint);$en=@($ent.EndPoint)
      if($st.Count -ge 2 -and $en.Count -ge 2){
        $segments.Add(@{a=@([double]$st[0],[double]$st[1]);b=@([double]$en[0],[double]$en[1]);layer=$layer;handle=$handle;sourceId=$sourceId;sourceKind='line';sourcePointCount=2;closed=$false;hasArc=$false;source=$source})|Out-Null
      }
      return
    }
    if($name -notmatch 'Polyline$' -and $name -notin @('AcDbPolyline','AcDb2dPolyline','AcDb3dPolyline')){return}
    $isClosed=[bool]$ent.Closed
    $c=@($ent.Coordinates);$pts=New-Object System.Collections.Generic.List[object]
    $step=2
    if($name -match '3d'){$step=3}
    elseif(($c.Count % 2) -ne 0 -and ($c.Count % 3) -eq 0){$step=3}
    for($i=0;$i+$step-1 -lt $c.Count;$i+=$step){
      $x=[double]$c[$i];$y=[double]$c[$i+1]
      if([double]::IsNaN($x) -or [double]::IsInfinity($x) -or [double]::IsNaN($y) -or [double]::IsInfinity($y)){continue}
      $pts.Add(@($x,$y))|Out-Null
    }
    if($pts.Count -lt 2){return}
    $bulges=New-Object System.Collections.Generic.List[double]
    for($bi=0;$bi -lt $pts.Count;$bi++){
      $bv=0.0;try{$bv=[double]$ent.GetBulge($bi)}catch{}
      if([double]::IsNaN($bv) -or [double]::IsInfinity($bv)){$bv=0.0}
      $bulges.Add($bv)|Out-Null
    }
    $edgeCount=$pts.Count-1;if($isClosed){$edgeCount=$pts.Count}
    for($i=0;$i -lt $edgeCount;$i++){
      $j=($i+1)%$pts.Count
      $x1=[double]$pts[$i][0];$y1=[double]$pts[$i][1];$x2=[double]$pts[$j][0];$y2=[double]$pts[$j][1]
      $dx=$x2-$x1;$dy=$y2-$y1;$chord=[math]::Sqrt($dx*$dx+$dy*$dy)
      if($chord -lt 1e-9){continue}
      $bulge=[double]$bulges[$i]
      if([math]::Abs($bulge) -gt 1e-10){
        $theta=4.0*[math]::Atan($bulge)
        $offset=$chord*(1.0-$bulge*$bulge)/(4.0*$bulge)
        $cx=($x1+$x2)/2.0-($dy/$chord)*$offset
        $cy=($y1+$y2)/2.0+($dx/$chord)*$offset
        $radius=[math]::Sqrt(($x1-$cx)*($x1-$cx)+($y1-$cy)*($y1-$cy))
        if([double]::IsNaN($radius) -or [double]::IsInfinity($radius) -or $radius -lt 1e-9 -or [double]::IsNaN($theta) -or [double]::IsInfinity($theta)){
          $segments.Add(@{a=@($x1,$y1);b=@($x2,$y2);layer=$layer;handle=$handle;sourceId=$sourceId;sourceKind='polyline';sourcePointCount=$pts.Count;closed=$isClosed;hasArc=$true;source=$source})|Out-Null
          continue
        }
        $startAngle=[math]::Atan2($y1-$cy,$x1-$cx)
        $steps=[int][math]::Ceiling([math]::Abs($theta)/([math]::PI/60.0))
        if($steps -lt 1){$steps=1};if($steps -gt 720){$steps=720}
        $px=$x1;$py=$y1
        for($k=1;$k -le $steps;$k++){
          if($k -eq $steps){$nx=$x2;$ny=$y2}
          else{$ang=$startAngle+$theta*$k/$steps;$nx=$cx+$radius*[math]::Cos($ang);$ny=$cy+$radius*[math]::Sin($ang)}
          $segments.Add(@{a=@([double]$px,[double]$py);b=@([double]$nx,[double]$ny);layer=$layer;handle=$handle;sourceId=$sourceId;sourceKind='polyline';sourcePointCount=$pts.Count;closed=$isClosed;hasArc=$true;source=$source})|Out-Null
          $px=$nx;$py=$ny
        }
      } else {
        $segments.Add(@{a=@($x1,$y1);b=@($x2,$y2);layer=$layer;handle=$handle;sourceId=$sourceId;sourceKind='polyline';sourcePointCount=$pts.Count;closed=$isClosed;hasArc=$false;source=$source})|Out-Null
      }
    }
  } catch { }
}
function Add-AcadBlockRefFeatures([System.Collections.IList]$features,$doc,$ref,[System.Collections.IList]$guardSegments=$null){
  # Reads the block definition read-only and applies the insertion transform in memory.
  # (The old code called $ref.Explode(), which creates real entities inside the user's drawing on every poll.)
  try {
    $blk=$doc.Blocks.Item([string]$ref.Name)
    $ip=@($ref.InsertionPoint)
    $sx=[double]$ref.XScaleFactor; $sy=[double]$ref.YScaleFactor; $rot=[double]$ref.Rotation
    $ox=0.0; $oy=0.0
    try { $org=@($blk.Origin); $ox=[double]$org[0]; $oy=[double]$org[1] } catch { }
    $cs=[math]::Cos($rot); $sn=[math]::Sin($rot)
    for($k=0;$k -lt $blk.Count;$k++){
      $blockEnt=$blk.Item($k)
      $tmp=New-Object System.Collections.Generic.List[object]
      $blockSource='BlockReference:'+([string]$ref.Handle)
      Add-AcadPolylineFeature $tmp $blockEnt $blockSource
      foreach($tf in $tmp){
        $nr=New-Object System.Collections.Generic.List[object]
        foreach($pt in $tf.geometry.coordinates[0]){
          $lx=([double]$pt[0]-$ox)*$sx; $ly=([double]$pt[1]-$oy)*$sy
          $nr.Add(@(([double]$ip[0]+$lx*$cs-$ly*$sn),([double]$ip[1]+$lx*$sn+$ly*$cs))) | Out-Null
        }
        $tf.geometry.coordinates=@(,($nr.ToArray()))
        $features.Add($tf) | Out-Null
      }
      if($guardSegments){
        $tmpGuards=New-Object System.Collections.Generic.List[object]
        Add-AcadProtectionSegments $tmpGuards $blockEnt $blockSource
        foreach($g in $tmpGuards){
          foreach($key in @('a','b')){
            $pt=@($g[$key]);$lx=([double]$pt[0]-$ox)*$sx;$ly=([double]$pt[1]-$oy)*$sy
            $g[$key]=@(([double]$ip[0]+$lx*$cs-$ly*$sn),([double]$ip[1]+$lx*$sn+$ly*$cs))
          }
          if(([string]$g.layer -eq '0') -and $ref.Layer){$g.layer=[string]$ref.Layer}
          $guardSegments.Add($g)|Out-Null
        }
      }
    }
  } catch { }
}
function Get-ActiveAutoCADPolygons {
  $acad=Get-RunningAutoCAD
  if(-not $acad){ throw 'ERR_ACAD_NOT_CONNECTED' }
  try{$doc=$acad.ActiveDocument}catch{$script:AcadObj=$null;throw 'ERR_ACAD_NOT_CONNECTED'}
  if(-not $doc){throw 'ERR_ACAD_NOT_CONNECTED'}
  $features=New-Object System.Collections.Generic.List[object]
  $guardSegments=New-Object System.Collections.Generic.List[object]
  $ms=$doc.ModelSpace
  $n=$ms.Count
  for($i=0;$i -lt $n;$i++){
    $ent=$ms.Item($i)
    Add-AcadPolylineFeature $features $ent 'ModelSpace'
    Add-AcadProtectionSegments $guardSegments $ent 'ModelSpace'
    try{
      if([string]$ent.ObjectName -eq 'AcDbBlockReference'){ Add-AcadBlockRefFeatures $features $doc $ent $guardSegments }
    } catch { }
  }
  if($features.Count -eq 0){throw 'ERR_NO_CLOSED_POLYLINES'}
  $name='';$path=''
  try{$name=[string]$doc.Name}catch{}
  try{$path=[string]$doc.FullName}catch{}
  # v20: the fingerprint now covers EVERY vertex (the old one only saw the first point, so editing
  # any other vertex never triggered a refresh).
  $inv=[Globalization.CultureInfo]::InvariantCulture
  $rows=New-Object System.Collections.Generic.List[string]
  foreach($f in $features){
    $ringStr=(@($f.geometry.coordinates[0]) | ForEach-Object { ([double]$_[0]).ToString('0.####',$inv)+','+([double]$_[1]).ToString('0.####',$inv) }) -join ';'
    $rows.Add(([string]$f.properties.handle)+'|'+$ringStr)|Out-Null
  }
  $sortedRows=@($rows | Sort-Object)
  foreach($g in $guardSegments){
    $gstr=([string]$g.handle)+'|'+([string]$g.layer)+'|'+([double]$g.a[0]).ToString('0.####',$inv)+','+([double]$g.a[1]).ToString('0.####',$inv)+'>'+([double]$g.b[0]).ToString('0.####',$inv)+','+([double]$g.b[1]).ToString('0.####',$inv)
    $rows.Add('G|'+$gstr)|Out-Null
  }
  $sortedRows=@($rows | Sort-Object)
  $signature=[string]::Join("`n",$sortedRows)
  $bytes=[Text.Encoding]::UTF8.GetBytes($signature)
  $sha=[Security.Cryptography.SHA256]::Create()
  try{$fp=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
  return @{ok=$true;documentName=$name;documentPath=$path;units=Get-AcadUnitsCode $doc;fingerprint=$fp;count=$features.Count;protectionSegments=@($guardSegments.ToArray());fc=@{type='FeatureCollection';features=@($features.ToArray())}}
}
# ===================== v48: DWG -> DXF conversion (hardened) =====================
# Root causes fixed here (DXF always worked; DWG failed silently):
#  1) AutoCAD's script file is ANSI. Any non-ASCII character in a path (Arabic folder or user name, e.g.
#     D:\<arabic>\ or C:\Users\<arabic>\AppData\Temp) was turned into '?' so accoreconsole never wrote the DXF.
#     -> every conversion now runs in an ASCII-only work folder (C:\Users\Public\AhkamWork ...).
#  2) accoreconsole output was thrown away, so failures were invisible. -> its output is captured and logged.
#  3) A single script variant and no way to see what failed. -> two script variants + /dwg-diagnose endpoint.
$script:ConvLog = New-Object System.Collections.ArrayList
$script:AsciiWorkRoot = $null
function Add-ConvLog([string]$m) { [void]$script:ConvLog.Add($m); Write-Log ('DWG ' + $m) }
function Test-AsciiPath([string]$p) { return ($p -match '^[\x20-\x7E]+$') }

function Get-AsciiWorkRoot {
  if ($script:AsciiWorkRoot -and (Test-Path -LiteralPath $script:AsciiWorkRoot)) { return $script:AsciiWorkRoot }
  $cands = New-Object System.Collections.ArrayList
  if ($env:PUBLIC)      { [void]$cands.Add((Join-Path $env:PUBLIC 'AhkamWork')) }
  if ($env:ProgramData) { [void]$cands.Add((Join-Path $env:ProgramData 'AhkamWork')) }
  if ($env:SystemRoot)  { [void]$cands.Add((Join-Path $env:SystemRoot 'Temp\AhkamWork')) }
  if ($env:SystemDrive) { [void]$cands.Add(($env:SystemDrive + '\AhkamWork')) }
  [void]$cands.Add((Join-Path ([IO.Path]::GetTempPath()) 'AhkamWork'))
  foreach ($c in $cands) {
    if (-not (Test-AsciiPath $c)) { continue }
    try {
      New-Item -ItemType Directory -Path $c -Force -ErrorAction Stop | Out-Null
      $probe = Join-Path $c ('probe_' + [Guid]::NewGuid().ToString('N') + '.tmp')
      [IO.File]::WriteAllText($probe, 'x')
      Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
      $script:AsciiWorkRoot = $c
      return $c
    } catch { }
  }
  throw 'ERR_NO_ASCII_WORKDIR'
}

function New-JobDir {
  $d = Join-Path (Get-AsciiWorkRoot) ('j' + [Guid]::NewGuid().ToString('N').Substring(0, 12))
  New-Item -ItemType Directory -Path $d -Force | Out-Null
  return $d
}

function Clear-OldJobs {
  try {
    $r = Get-AsciiWorkRoot
    Get-ChildItem -LiteralPath $r -Directory -ErrorAction SilentlyContinue |
      Where-Object { $_.LastWriteTime -lt (Get-Date).AddHours(-12) } |
      ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
  } catch { }
}

function Stop-ProcessTree([int]$id) {
  try {
    Get-CimInstance Win32_Process -Filter ('ParentProcessId=' + $id) -ErrorAction SilentlyContinue |
      ForEach-Object { Stop-ProcessTree ([int]$_.ProcessId) }
  } catch { }
  try { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue } catch { }
}

function Add-ConvTail([string]$file) {
  try {
    if (Test-Path -LiteralPath $file) {
      $bytes = [IO.File]::ReadAllBytes($file); if ($bytes.Length -ge 2 -and $bytes[1] -eq 0) { $t = [Text.Encoding]::Unicode.GetString($bytes) } else { $t = [Text.Encoding]::Default.GetString($bytes) }
      $t = ($t -replace '[^\x20-\x7E\r\n]', '?').Trim()
      if ($t.Length -gt 700) { $t = $t.Substring($t.Length - 700) }
      if ($t) { Add-ConvLog ('OUTPUT: ' + ($t -replace '\s+', ' ')) }
    }
  } catch { }
}

function Get-DwgVersionInfo([string]$path) {
  $fs = $null
  try {
    $fs = [IO.File]::OpenRead($path)
    $b = New-Object byte[] 6
    [void]$fs.Read($b, 0, 6)
    $h = [Text.Encoding]::ASCII.GetString($b)
    $map = @{ 'AC1015' = '2000'; 'AC1018' = '2004'; 'AC1021' = '2007'; 'AC1024' = '2010'; 'AC1027' = '2013'; 'AC1032' = '2018+' }
    if ($h -notmatch '^AC10\d\d$') { return $null }
    if ($map.ContainsKey($h)) { return ($h + ' (AutoCAD ' + $map[$h] + ')') }
    return $h
  } catch { return $null } finally { if ($fs) { $fs.Dispose() } }
}

function Find-AccoreConsoles {
  if ($script:AccoreList) { $ok = $true; foreach ($x in $script:AccoreList) { if (-not (Test-Path -LiteralPath $x)) { $ok = $false } }; if ($ok) { return ,$script:AccoreList } }
  $bases = @("$env:ProgramFiles\Autodesk", "${env:ProgramFiles(x86)}\Autodesk", "$env:ProgramW6432\Autodesk")
  $found = New-Object System.Collections.ArrayList
  foreach ($b in $bases) {
    if (-not $b -or -not (Test-Path -LiteralPath $b)) { continue }
    # fast path: Autodesk\<product folder>\accoreconsole.exe (AutoCAD, Civil 3D, Map 3D, Architecture ...)
    try {
      Get-ChildItem -LiteralPath $b -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        $f = Join-Path $_.FullName 'accoreconsole.exe'
        if ((Test-Path -LiteralPath $f) -and -not $found.Contains($f)) { [void]$found.Add($f) }
      }
    } catch { }
  }
  if ($found.Count -eq 0) {
    foreach ($b in $bases) {
      if (-not $b -or -not (Test-Path -LiteralPath $b)) { continue }
      try {
        Get-ChildItem -LiteralPath $b -Filter 'accoreconsole.exe' -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
          if (-not $found.Contains($_.FullName)) { [void]$found.Add($_.FullName) }
        }
      } catch { }
    }
  }
  $sorted = @($found | Sort-Object -Descending)
  $script:AccoreList = $sorted
  return ,$sorted
}
function Find-AccoreConsole {
  $l = Find-AccoreConsoles
  if ($l -and $l.Count -gt 0) { return $l[0] }
  return $null
}

function Find-OdaConverter {
  $bases = @("$env:ProgramFiles\ODA", "${env:ProgramFiles(x86)}\ODA", "$env:ProgramFiles\Open Design Alliance")
  foreach ($b in $bases) {
    if (-not $b -or -not (Test-Path -LiteralPath $b)) { continue }
    try {
      $hit = Get-ChildItem -LiteralPath $b -Filter 'ODAFileConverter.exe' -Recurse -ErrorAction SilentlyContinue |
             Sort-Object FullName -Descending | Select-Object -First 1
      if ($hit) { return $hit.FullName }
    } catch { }
  }
  return $null
}

function Convert-ViaCoreConsole([string]$exe, [string]$dwg, [string]$dxf, [string]$workdir) {
  # NOTE: FILEDIA is intentionally NOT touched (it lives in the user's AutoCAD profile).
  $dxfLisp = $dxf -replace '\\', '/'
  $variants = @(
    @{ name = 'dxfout';  lines = @('_.DXFOUT', $dxf, '16', '_.QUIT', '_Y') },
    @{ name = 'lisp';    lines = @(('(command \"_.DXFOUT\" \"' + $dxfLisp + '\" \"16\")'), '_.QUIT', '_Y') },
    @{ name = 'saveas';  lines = @('_.SAVEAS', 'DXF', $dxf, '_.QUIT', '_Y') }
  )
  foreach ($v in $variants) {
    if (Test-Path -LiteralPath $dxf) { Remove-Item -LiteralPath $dxf -Force -ErrorAction SilentlyContinue }
    $scr = Join-Path $workdir ('acc_' + $v.name + '.scr')
    $so  = Join-Path $workdir ('acc_' + $v.name + '_out.txt')
    [IO.File]::WriteAllText($scr, (($v.lines -join "`r`n") + "`r`n"), [Text.Encoding]::ASCII)
    $procArgs = @('/i', ('"' + $dwg + '"'), '/s', ('"' + $scr + '"'), '/l', 'en-US')
    Add-ConvLog ('ACCORE start variant=' + $v.name + ' exe=' + $exe)
    $p = $null
    try {
      $p = Start-Process -FilePath $exe -ArgumentList $procArgs -WindowStyle Hidden -PassThru -RedirectStandardOutput $so
      $exited = $p.WaitForExit(120000)
      if (-not $exited) { Stop-ProcessTree $p.Id; Add-ConvLog 'ACCORE timeout after 120s (killed)' }
      else { Add-ConvLog ('ACCORE exit=' + $p.ExitCode) }
    } catch { Add-ConvLog ('ACCORE launch error: ' + $_.Exception.Message) }
    Add-ConvTail $so
    if ((Test-Path -LiteralPath $dxf) -and ((Get-Item -LiteralPath $dxf).Length -gt 64)) { Add-ConvLog ('ACCORE ok variant=' + $v.name); return $true }
    Add-ConvLog ('ACCORE produced no DXF (variant=' + $v.name + ')')
  }
  return $false
}

function Convert-ViaOda([string]$exe, [string]$dwg, [string]$dxf, [string]$workdir) {
  $inDir = Join-Path $workdir 'oda_in'
  $outDir = Join-Path $workdir 'oda_out'
  New-Item -ItemType Directory -Path $inDir -Force | Out-Null
  New-Item -ItemType Directory -Path $outDir -Force | Out-Null
  Copy-Item -LiteralPath $dwg -Destination (Join-Path $inDir 'input.dwg') -Force
  $procArgs = @(('"' + $inDir + '"'), ('"' + $outDir + '"'), 'ACAD2013', 'DXF', '0', '1', '"*.DWG"')
  Add-ConvLog ('ODA start exe=' + $exe)
  $p = Start-Process -FilePath $exe -ArgumentList $procArgs -WindowStyle Hidden -PassThru
  $exited = $p.WaitForExit(120000)
  if (-not $exited) { Stop-ProcessTree $p.Id; Add-ConvLog 'ODA timeout after 120s (killed)' } else { Add-ConvLog ('ODA exit=' + $p.ExitCode) }
  $made = Get-ChildItem -LiteralPath $outDir -Filter '*.dxf' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($made -and $made.Length -gt 64) { Copy-Item -LiteralPath $made.FullName -Destination $dxf -Force; Add-ConvLog 'ODA ok'; return $true }
  $errf = Get-ChildItem -LiteralPath $outDir -Filter '*.err' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($errf) { Add-ConvTail $errf.FullName }
  Add-ConvLog 'ODA produced no DXF'
  return $false
}

function Convert-Dwg([string]$dwg, [string]$dxf, [string]$workdir) {
  $script:ConvLog.Clear()
  $ver = Get-DwgVersionInfo $dwg
  if (-not $ver) { Add-ConvLog 'input is not a valid DWG (bad header)'; throw 'ERR_DWG_BAD_HEADER' }
  Add-ConvLog ('input header=' + $ver + ' workdir=' + $workdir)
  $accs = @(Find-AccoreConsoles)
  $tried = 0
  foreach ($acc in $accs) {
    if ($tried -ge 2) { break }
    $tried++
    try { if (Convert-ViaCoreConsole $acc $dwg $dxf $workdir) { Write-Log 'CONVERT_METHOD accoreconsole'; return } }
    catch { Add-ConvLog ('ACCORE exception: ' + $_.Exception.Message) }
  }
  if ($accs.Count -eq 0) { Add-ConvLog 'accoreconsole.exe not found (AutoCAD LT has none; full AutoCAD / Civil 3D / Map 3D do)' }

  # COM automation of a running AutoCAD was REMOVED on purpose: it attached to the user's
  # open AutoCAD, hid it (Visible=false), opened/closed documents in it and left a hidden
  # acad.exe behind. The tool must never touch the user's live AutoCAD session.

  $oda = Find-OdaConverter
  if ($oda) {
    try { if (Convert-ViaOda $oda $dwg $dxf $workdir) { Write-Log 'CONVERT_METHOD oda'; return } }
    catch { Add-ConvLog ('ODA exception: ' + $_.Exception.Message) }
  } else { Add-ConvLog 'ODAFileConverter.exe not found' }

  if ($accs.Count -eq 0 -and -not $oda) { throw 'ERR_AUTOCAD_NOT_FOUND' }
  throw 'ERR_DXF_SAVE_FAILED'
}

function Test-DwgSignature([string]$path) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $false }
  try {
    $fs = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    try {
      if ($fs.Length -lt 64) { return $false }
      $buf = New-Object byte[] 6
      if ($fs.Read($buf, 0, 6) -ne 6) { return $false }
      return ([Text.Encoding]::ASCII.GetString($buf) -match '^AC10[0-9]{2}$')
    } finally { $fs.Dispose() }
  } catch { return $false }
}

function Convert-DxfViaCoreConsole([string]$exe, [string]$dxf, [string]$dwg, [string]$workdir) {
  $scr = Join-Path $workdir 'to_dwg.scr'
  $outPath = $dwg -replace '\\', '/'
  if (Test-Path -LiteralPath $dwg) { Remove-Item -LiteralPath $dwg -Force -ErrorAction SilentlyContinue }
  # This process is isolated from the user's live AutoCAD session.
  $lines = @(
    '_.FILEDIA',
    '0',
    '_.CMDDIA',
    '0',
    '_.ZOOM',
    '_EXTENTS',
    '_.-SAVEAS',
    '_2018',
    '"' + $outPath + '"',
    '_.QUIT'
  )
  Set-Content -LiteralPath $scr -Value $lines -Encoding ASCII
  $procArgs = @('/i', ('"' + $dxf + '"'), '/s', ('"' + $scr + '"'), '/l', 'en-US')
  $p = Start-Process -FilePath $exe -ArgumentList $procArgs -WindowStyle Hidden -PassThru
  $exited = $p.WaitForExit(180000)
  if (-not $exited) { try { $p.Kill() } catch { }; throw 'ERR_DWG_CONVERT_TIMEOUT' }
  $p.Refresh()
  if ($p.ExitCode -ne 0) { Write-Log ('ACCORE_DWG_EXITCODE ' + $p.ExitCode) }
  return (Test-DwgSignature $dwg)
}
function Convert-DxfViaOda([string]$exe, [string]$dxf, [string]$dwg, [string]$workdir) {
  $inDir = Join-Path $workdir 'oda_dxf_in'
  $outDir = Join-Path $workdir 'oda_dwg_out'
  New-Item -ItemType Directory -Path $inDir -Force | Out-Null
  New-Item -ItemType Directory -Path $outDir -Force | Out-Null
  Copy-Item -LiteralPath $dxf -Destination (Join-Path $inDir 'input.dxf') -Force
  $procArgs = @(('"' + $inDir + '"'), ('"' + $outDir + '"'), 'ACAD2018', 'DWG', '0', '1', '"*.DXF"')
  $p = Start-Process -FilePath $exe -ArgumentList $procArgs -WindowStyle Hidden -PassThru
  $exited = $p.WaitForExit(180000)
  if (-not $exited) { try { $p.Kill() } catch { }; throw 'ERR_DWG_CONVERT_TIMEOUT' }
  $made = Get-ChildItem -LiteralPath $outDir -Filter '*.dwg' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($made -and (Test-DwgSignature $made.FullName)) { Copy-Item -LiteralPath $made.FullName -Destination $dwg -Force; return (Test-DwgSignature $dwg) }
  return $false
}
function Convert-DxfToDwg([string]$dxf, [string]$dwg, [string]$workdir) {
  $acc = Find-AccoreConsole
  if ($acc) {
    Write-Log ('TRY_DXF_TO_DWG_ACCORE ' + $acc)
    try { if (Convert-DxfViaCoreConsole $acc $dxf $dwg $workdir) { Write-Log 'DXF_TO_DWG_METHOD accoreconsole'; return } }
    catch { Write-Log ('DXF_TO_DWG_ACCORE_FAILED ' + $_.Exception.Message) }
    if (Test-Path -LiteralPath $dwg) { Remove-Item -LiteralPath $dwg -Force -ErrorAction SilentlyContinue }
  }
  $oda = Find-OdaConverter
  if ($oda) {
    Write-Log ('TRY_DXF_TO_DWG_ODA ' + $oda)
    try { if (Convert-DxfViaOda $oda $dxf $dwg $workdir) { Write-Log 'DXF_TO_DWG_METHOD oda'; return } }
    catch { Write-Log ('DXF_TO_DWG_ODA_FAILED ' + $_.Exception.Message) }
  }
  if (-not $acc -and -not $oda) { throw 'ERR_DWG_CONVERTER_NOT_FOUND' }
  throw 'ERR_DWG_CONVERT_FAILED'
}

# One-time self-repair: older builds left FILEDIA=0 in the AutoCAD profile registry, which makes
# the Open button print prompts on the command line instead of showing a dialog.
function Repair-AutoCadFileDia {
  try {
    $roots = @('HKCU:\Software\Autodesk\AutoCAD')
    foreach ($r in $roots) {
      if (-not (Test-Path -LiteralPath $r)) { continue }
      Get-ChildItem -LiteralPath $r -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.PSChildName -eq 'Variables' } | ForEach-Object {
          try {
            $v = (Get-ItemProperty -LiteralPath $_.PSPath -Name 'FILEDIA' -ErrorAction SilentlyContinue).FILEDIA
            if ($null -ne $v -and "$v" -ne '1') {
              Set-ItemProperty -LiteralPath $_.PSPath -Name 'FILEDIA' -Value '1'
              Write-Log ('REPAIRED_FILEDIA ' + $_.PSPath)
            }
          } catch { }
        }
    }
  } catch { }
}

# ================= v49: ONE-CLICK UPDATE + LOCAL LIBS =================
function Get-LocalVersionInfo {
  $v = $AHKAM_VERSION
  $b = 0
  try {
    $vf = Join-Path $root 'version.json'
    if (Test-Path -LiteralPath $vf -PathType Leaf) {
      $o = ([IO.File]::ReadAllText($vf, [Text.Encoding]::UTF8)).TrimStart([char]0xFEFF) | ConvertFrom-Json
      if ($o.version) { $v = [string]$o.version }
      $b = [int]$o.build
    }
  } catch { }
  return @{ version = $v; build = $b }
}

function Get-UpdateManifestUrl {
  try {
    $cf = Join-Path $root 'update.config.json'
    if (Test-Path -LiteralPath $cf -PathType Leaf) {
      $o = ([IO.File]::ReadAllText($cf, [Text.Encoding]::UTF8)).TrimStart([char]0xFEFF) | ConvertFrom-Json
      $u = ([string]$o.manifestUrl).Trim()
      if ($u -match '^https://[^\s]+$') { return $u }
    }
  } catch { }
  return ''
}

function Get-UpdateManifest([string]$url) {
  $sep = '?'
  if ($url.Contains('?')) { $sep = '&' }
  $r = Invoke-WebRequest -UseBasicParsing -Uri ($url + $sep + 'nocache=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 8 -Headers @{ 'Cache-Control' = 'no-cache' }
  $c = $r.Content
  if ($c -is [byte[]]) { $c = [Text.Encoding]::UTF8.GetString($c) }
  $txt = ([string]$c).TrimStart([char]0xFEFF)
  return ($txt | ConvertFrom-Json)
}

function Invoke-UpdateCheck {
  $cur = Get-LocalVersionInfo
  $url = Get-UpdateManifestUrl
  if (-not $url) { return @{ ok = $true; configured = $false; available = $false; current = $cur } }
  try {
    $m = Get-UpdateManifest $url
    $avail = ([int]$m.build -gt [int]$cur.build)
    return @{ ok = $true; configured = $true; available = $avail; current = $cur; latest = @{ version = [string]$m.version; build = [int]$m.build; notes = [string]$m.notes } }
  } catch {
    Write-Log ('UPDATE_CHECK_FAILED ' + $_.Exception.Message)
    return @{ ok = $false; configured = $true; available = $false; current = $cur; error = 'ERR_UPDATE_DOWNLOAD' }
  }
}

function Test-ScriptSyntax([string]$file) {
  $tok = $null
  $perr = $null
  [void][System.Management.Automation.Language.Parser]::ParseFile($file, [ref]$tok, [ref]$perr)
  return (-not $perr -or $perr.Count -eq 0)
}

function Invoke-UpdateApply {
  if (-not $script:Licensed) { throw 'ERR_UPDATE_LICENSE' }
  $cur = Get-LocalVersionInfo
  $url = Get-UpdateManifestUrl
  if (-not $url) { throw 'ERR_UPDATE_NOT_CONFIGURED' }
  $m = $null
  try { $m = Get-UpdateManifest $url } catch { Write-Log ('UPDATE_MANIFEST_FAILED ' + $_.Exception.Message); throw 'ERR_UPDATE_DOWNLOAD' }
  if ([int]$m.build -le [int]$cur.build) { throw 'ERR_UPDATE_NONE' }
  $zipUrl = [string]$m.url
  if (($zipUrl -notmatch '^https://[^\s]+$') -or (-not $m.sig)) { throw 'ERR_UPDATE_BAD_MANIFEST' }
  $stage = Join-Path $root 'update_tmp'
  try {
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    $zipFile = Join-Path $stage 'update.zip'
    try { Invoke-WebRequest -UseBasicParsing -Uri $zipUrl -OutFile $zipFile -TimeoutSec 900 } catch { Write-Log ('UPDATE_DOWNLOAD_FAILED ' + $_.Exception.Message); throw 'ERR_UPDATE_DOWNLOAD' }
    # 1) integrity + 2) seller signature: nothing unsigned is ever installed
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $fs = [IO.File]::OpenRead($zipFile)
    $hash = $null
    try { $hash = $sha.ComputeHash($fs) } finally { $fs.Dispose() }
    $hex = (($hash | ForEach-Object { $_.ToString('x2') }) -join '')
    if ($m.sha256 -and (([string]$m.sha256).ToLowerInvariant() -ne $hex)) { throw 'ERR_UPDATE_HASH' }
    $okSig = $false
    try {
      $sig = [Convert]::FromBase64String([string]$m.sig)
      $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
      $rsa.FromXmlString($UPDATE_PUBLIC_KEY_XML)
      $oid = [System.Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256')
      $okSig = $rsa.VerifyHash($hash, $oid, $sig)
    } catch { $okSig = $false }
    if (-not $okSig) { Write-Log 'UPDATE_SIGNATURE_INVALID'; throw 'ERR_UPDATE_SIGNATURE' }
    # 3) unpack to staging and sanity-check before touching the live files
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $newDir = Join-Path $stage 'new'
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipFile, $newDir)
    foreach ($need in @('server.ps1', 'Ahkam_Tool.html', 'version.json')) {
      if (-not (Test-Path -LiteralPath (Join-Path $newDir $need) -PathType Leaf)) { throw 'ERR_UPDATE_BADPACKAGE' }
    }
    $nv = ([IO.File]::ReadAllText((Join-Path $newDir 'version.json'), [Text.Encoding]::UTF8)).TrimStart([char]0xFEFF) | ConvertFrom-Json
    if ([int]$nv.build -ne [int]$m.build) { throw 'ERR_UPDATE_BADPACKAGE' }
    if (-not (Test-ScriptSyntax (Join-Path $newDir 'server.ps1'))) { throw 'ERR_UPDATE_BADSCRIPT' }
    $runner = Join-Path $stage 'run_updater.ps1'
    $newUpd = Join-Path $newDir 'updater.ps1'
    $oldUpd = Join-Path $root 'updater.ps1'
    if ((Test-Path -LiteralPath $newUpd -PathType Leaf) -and (Test-ScriptSyntax $newUpd)) { Copy-Item -LiteralPath $newUpd -Destination $runner -Force }
    elseif (Test-Path -LiteralPath $oldUpd -PathType Leaf) { Copy-Item -LiteralPath $oldUpd -Destination $runner -Force }
    else { throw 'ERR_UPDATE_BADPACKAGE' }
    # 4) hand over to a hidden helper that waits for this server to exit, swaps files, restarts, and rolls back on failure
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $argStr = '-NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $runner + '" -Root "' + $root + '" -Port ' + $Port + ' -ServerPid ' + $PID
    Start-Process -FilePath $psExe -ArgumentList $argStr -WindowStyle Hidden | Out-Null
    Write-Log ('UPDATE_APPLY_STARTED from build ' + $cur.build + ' to ' + $m.build + ' (' + $m.version + ')')
    return @{ ok = $true; restarting = $true; version = [string]$m.version; build = [int]$m.build }
  } catch {
    $e = $_
    try { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue } } catch { }
    throw $e
  }
}

# Local copies of the map/zip libraries, so importing never depends on the internet.
# Missing files are downloaded once in the background; afterwards everything is served locally.
function Start-LibsDownload {
  $libDir = Join-Path $root 'lib'
  $items = @(
    @('leaflet.js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', 100000),
    @('leaflet.css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', 5000),
    @('images/layers.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/layers.png', 300),
    @('images/layers-2x.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/layers-2x.png', 300),
    @('images/marker-icon.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png', 300),
    @('images/marker-icon-2x.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png', 300),
    @('images/marker-shadow.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png', 300),
    @('shp.min.js', 'https://cdn.jsdelivr.net/npm/shpjs@6.1.0/dist/shp.min.js', 20000),
    @('proj4.js', 'https://cdn.jsdelivr.net/npm/proj4@2.11.0/dist/proj4.js', 20000)
  )
  $missing = New-Object System.Collections.ArrayList
  foreach ($it in $items) {
    $f = Join-Path $libDir (([string]$it[0]) -replace '/', '\')
    $bad = $true
    if (Test-Path -LiteralPath $f -PathType Leaf) { if ((Get-Item -LiteralPath $f).Length -ge [int]$it[2]) { $bad = $false } }
    if ($bad) { [void]$missing.Add($it) }
  }
  if ($missing.Count -eq 0) { return }
  Write-Log ('LIBS_MISSING ' + $missing.Count + ' - downloading in background')
  $ps = [PowerShell]::Create()
  [void]$ps.AddScript({
    param($libDir, $missing, $log)
    $ErrorActionPreference = 'Stop'
    $ProgressPreference = 'SilentlyContinue'
    foreach ($it in $missing) {
      $rel = [string]$it[0]
      try {
        $dst = Join-Path $libDir ($rel -replace '/', '\')
        $dir = Split-Path -Parent $dst
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $tmp = $dst + '.part'
        Invoke-WebRequest -UseBasicParsing -Uri ([string]$it[1]) -OutFile $tmp -TimeoutSec 40
        if ((Get-Item -LiteralPath $tmp).Length -lt [int]$it[2]) { Remove-Item -LiteralPath $tmp -Force; throw 'file too small' }
        Move-Item -LiteralPath $tmp -Destination $dst -Force
        Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  LIB_DOWNLOADED ' + $rel) -Encoding UTF8
      } catch {
        Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  LIB_DOWNLOAD_FAILED ' + $rel + ' ' + $_.Exception.Message) -Encoding UTF8
        break
      }
    }
  })
  [void]$ps.AddArgument($libDir)
  [void]$ps.AddArgument($missing.ToArray())
  [void]$ps.AddArgument($log)
  $script:LibsPs = $ps
  $script:LibsHandle = $ps.BeginInvoke()
}

$listener = $null
try {
  $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
  $listener.Start()
} catch {
  Write-Log ('BIND_FAILED port ' + $Port + ' : ' + $_.Exception.Message)
  # Try to stop an older Ahkam server instance that is using the same port.
  # Only accept a BYE response, so we do not send shutdown to an unrelated service.
  try {
    $old = Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 ("http://127.0.0.1:$Port/shutdown")
    if ($old.StatusCode -eq 200 -and $old.Content -eq 'BYE') {
      Write-Log 'OLD_AHKAM_INSTANCE_STOPPED'
      Start-Sleep -Milliseconds 400
      $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
      $listener.Start()
    }
  } catch {
    Write-Log ('OLD_INSTANCE_NOT_STOPPED ' + $_.Exception.Message)
  }
  $bound = $false
  try { $bound = $null -ne $listener -and $listener.Server.IsBound } catch { $bound = $false }
  if (-not $bound) { return }
}

Write-Log ("SERVER_READY $AHKAM_VERSION http://127.0.0.1:$Port/  root=$root")
Initialize-License
try { Clear-OldJobs } catch { }
try { Start-LibsDownload } catch { Write-Log ('LIBS_START_FAILED ' + $_.Exception.Message) }
$running = $true

while ($running) {
  $client = $null
  $stream = $null
  $gotHeader = $false
  try {
    $gotHeader = $false
    $client = $listener.AcceptTcpClient()
    # v19: browsers open idle "preconnect" sockets that never send a request. With a 5 minute
    # timeout they froze this single-threaded loop (buttons looked dead). Header must arrive fast.
    $client.ReceiveTimeout = 1500
    $client.SendTimeout = 300000
    $stream = $client.GetStream()
    $stream.ReadTimeout = 1500

    $header = Read-HeaderBlock $stream
    if (-not $header) { continue }
    $gotHeader = $true
    $client.ReceiveTimeout = 300000
    $stream.ReadTimeout = 300000

    $lines = $header -split "`r`n"
    $parts = $lines[0] -split ' '
    if ($parts.Count -lt 2) { Send-Text $stream 400 'Bad Request' 'ERR_BAD_REQUEST'; continue }
    $method = $parts[0].ToUpperInvariant()
    $rawTarget = $parts[1]
    $qidx = $rawTarget.IndexOf('?')
    if ($qidx -ge 0) { $path = $rawTarget.Substring(0, $qidx); $query = $rawTarget.Substring($qidx + 1) }
    else { $path = $rawTarget; $query = '' }
    if ($path -eq '/') { $path = '/Ahkam_Tool.html' }

    $contentLength = 0
    $dirHeader = ''
    $nameHeader = ''
    foreach ($l in $lines) {
      if ($l -match '^(?i)content-length\s*:\s*(\d+)\s*$') { $contentLength = [int]$Matches[1] }
      if ($l -match '^(?i)x-ahkam-dir\s*:\s*(.*)$') { $dirHeader = $Matches[1].Trim() }
      if ($l -match '^(?i)x-ahkam-name\s*:\s*(.*)$') { $nameHeader = $Matches[1].Trim() }
    }

    # ---- license endpoints and gate ----
    if ($method -eq 'GET' -and $path -eq '/license-status') {
      Send-Json $stream 200 'OK' @{ licensed = $script:Licensed; reason = $script:LicReason; machineId = $script:MachineId; name = $script:LicName; exp = $script:LicExp }
      continue
    }
    if ($method -eq 'POST' -and $path -eq '/activate') {
      try {
        if ($contentLength -le 0 -or $contentLength -gt 20000) { throw 'ERR_BAD_LICENSE' }
        $lbody = [Text.Encoding]::UTF8.GetString((Read-Body $stream $contentLength))
        if (Test-LicenseText $lbody) {
          $lt = ($lbody -replace '\s', '')
          [IO.File]::WriteAllText((Join-Path $root 'license.key'), $lt, (New-Object System.Text.UTF8Encoding($false)))
          Write-Log 'LICENSE_ACTIVATED'
        } else { Write-Log ('LICENSE_REJECTED ' + $script:LicReason) }
        Send-Json $stream 200 'OK' @{ licensed = $script:Licensed; reason = $script:LicReason; machineId = $script:MachineId; name = $script:LicName; exp = $script:LicExp }
      } catch {
        Write-Log ('ACTIVATE_ERROR ' + $_.Exception.Message)
        Send-Text $stream 400 'Bad Request' 'ERR_BAD_LICENSE'
      }
      continue
    }
    if (-not $script:Licensed) {
      $isLicFree = ($path -eq '/health' -or $path -eq '/shutdown' -or $path -eq '/activate.html')
      if (-not $isLicFree) {
        if ($method -eq 'GET' -and $path -eq '/Ahkam_Tool.html') {
          $af = Join-Path $root 'activate.html'
          if (Test-Path -LiteralPath $af -PathType Leaf) { Send-Response $stream 200 'OK' 'text/html; charset=utf-8' ([IO.File]::ReadAllBytes($af)) }
          else { Send-Text $stream 403 'Forbidden' 'ERR_LICENSE' }
        } else {
          Send-Text $stream 403 'Forbidden' 'ERR_LICENSE'
        }
        continue
      }
    }

    if ($method -eq 'GET' -and $path -eq '/health') {
      Send-Text $stream 200 'OK' ("OK|$AHKAM_VERSION|$root")
      continue
    }
    if ($method -eq 'GET' -and $path -eq '/shutdown') {
      Send-Text $stream 200 'OK' 'BYE'
      $running = $false
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/update-check') {
      try { Send-Json $stream 200 'OK' (Invoke-UpdateCheck) }
      catch { Write-Log ('UPDATE_CHECK_ERROR ' + $_.Exception.Message); Send-Json $stream 200 'OK' @{ ok = $false; error = 'ERR_UPDATE_DOWNLOAD' } }
      continue
    }
    if ($method -eq 'POST' -and $path -eq '/update-apply') {
      $ures = $null
      try {
        if ($contentLength -gt 0 -and $contentLength -lt 100000) { $null = Read-Body $stream $contentLength }
        $ures = Invoke-UpdateApply
      } catch {
        $ucode = [string]$_.Exception.Message
        if ($ucode -match '^ERR_UPDATE_[A-Z_]+$') { Write-Log ('UPDATE_APPLY_REFUSED ' + $ucode) }
        else { Write-Log ('UPDATE_APPLY_ERROR ' + $ucode); $ucode = 'ERR_UPDATE_BADPACKAGE' }
        $ures = @{ ok = $false; error = $ucode }
      }
      Send-Json $stream 200 'OK' $ures
      if ($ures.ok) { $running = $false }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/pick-cad-start') {
      try {
        $jid = Start-NativeOpenFileDialogJob -Filter 'DWG/DXF Files|*.dwg;*.dxf|All Files|*.*' -Title 'Select DWG or DXF File'
        Write-Log ('PICK_CAD_JOB_STARTED ' + $jid)
        Send-Json $stream 200 'OK' @{ ok = $true; id = $jid }
      } catch {
        Write-Log ('PICK_CAD_START_FAILED ' + $_.Exception.Message)
        Send-Text $stream 500 'Internal Server Error' 'ERR_PICK_FAILED'
      }
      continue
    }
    if ($method -eq 'GET' -and $path -eq '/pick-cad-poll') {
      try {
        $r = Get-NativeDialogJobResult (Get-QueryParam $query 'id')
        if ($r.path) { Write-Log ('PICK_CAD_OK ' + $r.path) }
        Send-Json $stream 200 'OK' $r
      } catch {
        Write-Log ('PICK_CAD_POLL_FAILED ' + $_.Exception.Message)
        Send-Text $stream 500 'Internal Server Error' 'ERR_PICK_FAILED'
      }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/pick-cad') {
      try {
        $picked = Show-NativeOpenFileDialog -Filter 'DWG/DXF Files|*.dwg;*.dxf|All Files|*.*' -Title 'Select DWG or DXF File'
        if ($null -eq $picked) {
          Send-Json $stream 200 'OK' @{ ok = $true; cancelled = $true }
        } else {
          Write-Log ('PICK_CAD_OK ' + $picked)
          Send-Json $stream 200 'OK' @{ ok = $true; path = $picked }
        }
      } catch {
        Write-Log ('PICK_CAD_FAILED ' + $_.Exception.Message)
        Send-Text $stream 500 'Internal Server Error' 'ERR_PICK_FAILED'
      }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/pick-folder') {
      try {
        $startDir = Get-QueryParam $query 'start'
        if (-not $startDir) { $startDir = '' }
        $picked = Show-NativeFolderDialog -Title 'اختر مجلد حفظ ملف Shapefile ZIP' -InitialPath $startDir
        if ($null -eq $picked) {
          Send-Json $stream 200 'OK' @{ ok = $true; cancelled = $true }
        } else {
          Write-Log ('PICK_FOLDER_OK ' + $picked)
          Send-Json $stream 200 'OK' @{ ok = $true; path = $picked }
        }
      } catch {
        Write-Log ('PICK_FOLDER_FAILED ' + $_.Exception.Message)
        Send-Text $stream 500 'Internal Server Error' 'ERR_PICK_FOLDER_FAILED'
      }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/cad-info') {
      $p = Get-QueryParam $query 'path'
      try {
        if (-not $p) { throw 'ERR_PATH_INVALID' }
        if ($p -notmatch '(?i)\.(dwg|dxf)$') { throw 'ERR_PATH_INVALID' }
        if (-not [IO.Path]::IsPathRooted($p)) { throw 'ERR_PATH_INVALID' }
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw 'ERR_PATH_INVALID' }
        $fi = Get-Item -LiteralPath $p -ErrorAction Stop
        Send-Json $stream 200 'OK' @{ ok = $true; path = $p; length = [int64]$fi.Length; lastWriteUtc = [int64]$fi.LastWriteTimeUtc.ToFileTimeUtc() }
      } catch {
        $code = $_.Exception.Message
        if ($code -notmatch '^ERR_') { Write-Log ('CAD_INFO_ERROR ' + $code); $code = 'ERR_READ_FAILED' }
        Send-Text $stream 400 'Bad Request' $code
      }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/acad-info') {
      try {
        $j = Get-ActiveAutoCADPolygons
        # info-only response still derives its fingerprint from current geometry.
        Send-Json $stream 200 'OK' @{ ok = $true; connected = $true; documentName = $j.documentName; documentPath = $j.documentPath; units = $j.units; fingerprint = $j.fingerprint; count = $j.count }
      } catch {
        $code=$_.Exception.Message
        if($code -notmatch '^ERR_'){$code='ERR_ACAD_NOT_CONNECTED'}
        Send-Text $stream 409 'Conflict' $code
      }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/read-active-autocad') {
      try {
        $j = Get-ActiveAutoCADPolygons
        Send-Json $stream 200 'OK' $j
      } catch {
        $code=$_.Exception.Message
        if($code -notmatch '^ERR_'){$code='ERR_ACAD_READ_FAILED'}
        Write-Log ('ACAD_READ_ERROR ' + $_.Exception.Message)
        Send-Text $stream 409 'Conflict' $code
      }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/read-cad') {
      $p = Get-QueryParam $query 'path'
      try {
        if (-not $p) { throw 'ERR_PATH_INVALID' }
        if ($p -notmatch '(?i)\.(dwg|dxf)$') { throw 'ERR_PATH_INVALID' }
        if (-not [IO.Path]::IsPathRooted($p)) { throw 'ERR_PATH_INVALID' }
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw 'ERR_PATH_INVALID' }
        $bytes = Read-FileShared $p
        $ct = if ($p -match '(?i)\.dwg$') { 'application/octet-stream' } else { 'application/dxf' }
        Send-Response $stream 200 'OK' $ct $bytes
      } catch {
        $code = $_.Exception.Message
        if ($code -notmatch '^ERR_') { Write-Log ('READ_CAD_ERROR ' + $code); $code = 'ERR_READ_FAILED' }
        Send-Text $stream 400 'Bad Request' $code
      }
      continue
    }

    # Local settings (place overrides and map key), stored next to the tool.
    if ($method -eq 'GET' -and $path -eq '/settings') {
      try {
        $pf = Join-Path $root 'ahkam_settings.json'
        if (Test-Path -LiteralPath $pf -PathType Leaf) {
          $pb = [IO.File]::ReadAllBytes($pf)
          Send-Response $stream 200 'OK' 'application/json; charset=utf-8' $pb
        } else {
          Send-Response $stream 200 'OK' 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes('[]'))
        }
      } catch {
        Write-Log ('SETTINGS_READ_ERROR ' + $_.Exception.Message)
        Send-Response $stream 200 'OK' 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes('[]'))
      }
      continue
    }
    if ($method -eq 'POST' -and $path -eq '/settings') {
      try {
        if ($contentLength -le 0 -or $contentLength -gt 500000) { throw 'ERR_SAVE_FAILED' }
        $data = Read-Body $stream $contentLength
        $txt = [Text.Encoding]::UTF8.GetString($data)
        $null = $txt | ConvertFrom-Json
        $pf = Join-Path $root 'ahkam_settings.json'
        [IO.File]::WriteAllBytes($pf, $data)
        Write-Log 'SETTINGS_SAVED'
        Send-Text $stream 200 'OK' 'OK'
      } catch {
        Write-Log ('SETTINGS_SAVE_ERROR ' + $_.Exception.Message)
        Send-Text $stream 500 'Internal Server Error' 'ERR_SAVE_FAILED'
      }
      continue
    }

    # Auto-saved per-parcel form drafts (smart link): survive closing the tool.
    if ($method -eq 'GET' -and $path -eq '/drafts') {
      $out = [Text.Encoding]::UTF8.GetBytes('{}')
      try {
        $pf = Join-Path $root 'ahkam_drafts.json'
        if (Test-Path -LiteralPath $pf -PathType Leaf) { $out = [IO.File]::ReadAllBytes($pf) }
      } catch { Write-Log ('DRAFTS_READ_ERROR ' + $_.Exception.Message) }
      Send-Response $stream 200 'OK' 'application/json; charset=utf-8' $out
      continue
    }
    if ($method -eq 'POST' -and $path -eq '/drafts') {
      try {
        if ($contentLength -le 0 -or $contentLength -gt 8000000) { throw 'ERR_SAVE_FAILED' }
        $data = Read-Body $stream $contentLength
        $null = [Text.Encoding]::UTF8.GetString($data) | ConvertFrom-Json
        $pf = Join-Path $root 'ahkam_drafts.json'
        $tmp = $pf + '.tmp'
        [IO.File]::WriteAllBytes($tmp, $data)
        Move-Item -LiteralPath $tmp -Destination $pf -Force
        Send-Text $stream 200 'OK' 'OK'
      } catch {
        Write-Log ('DRAFTS_SAVE_ERROR ' + $_.Exception.Message)
        Send-Text $stream 500 'Internal Server Error' 'ERR_SAVE_FAILED'
      }
      continue
    }

    if ($method -eq 'POST' -and $path -eq '/save-export') {
      try {
        if ($contentLength -le 0) { throw 'ERR_SAVE_FAILED' }
        $data = Read-Body $stream $contentLength
        $dir = [Uri]::UnescapeDataString($dirHeader)
        $name = [Uri]::UnescapeDataString($nameHeader)
        if (-not $dir -or -not $name) { throw 'ERR_BAD_NAME' }
        if ($name -match '[\\/:*?"<>|]' -or $name -match '\.\.') { throw 'ERR_BAD_NAME' }
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) { throw 'ERR_DIR_MISSING' }
        $full = Join-Path $dir $name
        $fullResolved = [IO.Path]::GetFullPath($full)
        $dirResolved = [IO.Path]::GetFullPath($dir)
        if (-not $fullResolved.StartsWith($dirResolved, [StringComparison]::OrdinalIgnoreCase)) { throw 'ERR_BAD_NAME' }
        [IO.File]::WriteAllBytes($fullResolved, $data)
        Write-Log ('SAVE_EXPORT_OK ' + $fullResolved)
        Send-Text $stream 200 'OK' $fullResolved
      } catch {
        $code = $_.Exception.Message
        if ($code -notmatch '^ERR_') { Write-Log ('SAVE_EXPORT_ERROR ' + $code); $code = 'ERR_SAVE_FAILED' }
        else { Write-Log ('SAVE_EXPORT_ERROR ' + $code) }
        Send-Text $stream 500 'Internal Server Error' $code
      }
      continue
    }

    if ($method -eq 'GET' -and $path -eq '/dwg-diagnose') {
      try {
        $accs = @(Find-AccoreConsoles)
        $oda = Find-OdaConverter
        $wr = $null; $werr = ''
        try { $wr = Get-AsciiWorkRoot } catch { $werr = $_.Exception.Message }
        Send-Json $stream 200 'OK' @{ ok = $true; version = $AHKAM_VERSION; accoreconsole = $accs; oda = $oda; workRoot = $wr; workError = $werr; toolFolder = $root; toolFolderAscii = (Test-AsciiPath $root); lastConversion = @($script:ConvLog) }
      } catch { Send-Text $stream 500 'Internal Server Error' 'ERR_SERVER' }
      continue
    }

    if ($method -eq 'POST' -and $path -eq '/convert-dxf-to-dwg') {
      if ($contentLength -lt 64) { Send-Text $stream 400 'Bad Request' 'ERR_DXF_EMPTY'; continue }
      $data = Read-Body $stream $contentLength
      $td = New-JobDir
      $dxf = Join-Path $td 'input.dxf'
      $dwg = Join-Path $td 'output.dwg'
      try {
        [IO.File]::WriteAllBytes($dxf, $data)
        Write-Log ("DXF_TO_DWG_START bytes=" + $data.Length)
        Convert-DxfToDwg $dxf $dwg $td
        if (-not (Test-DwgSignature $dwg)) { throw 'ERR_DWG_OUTPUT_INVALID' }
        $out = [IO.File]::ReadAllBytes($dwg)
        Write-Log ("DXF_TO_DWG_OK bytes=" + $out.Length)
        Send-Response $stream 200 'OK' 'application/octet-stream' $out
      } catch {
        $code = $_.Exception.Message
        if ($code -notmatch '^ERR_') { Write-Log ('DXF_TO_DWG_ERROR ' + $code); $code = 'ERR_DWG_CONVERT_FAILED' }
        else { Write-Log ('DXF_TO_DWG_ERROR ' + $code) }
        Send-Text $stream 500 'Internal Server Error' $code
      } finally {
        Remove-Item -LiteralPath $td -Recurse -Force -ErrorAction SilentlyContinue
      }
      continue
    }

    if ($method -eq 'POST' -and $path -eq '/convert-dwg') {
      if ($contentLength -lt 64) { Send-Text $stream 400 'Bad Request' 'ERR_DWG_EMPTY'; continue }
      $data = Read-Body $stream $contentLength
      $td = New-JobDir
      $dwg = Join-Path $td 'input.dwg'
      $dxf = Join-Path $td 'output.dxf'
      try {
        [IO.File]::WriteAllBytes($dwg, $data)
        Write-Log ("CONVERT_START bytes=" + $data.Length)
        Convert-Dwg $dwg $dxf $td
        $out = [IO.File]::ReadAllBytes($dxf)
        Write-Log ("CONVERT_OK bytes=" + $out.Length)
        Send-Response $stream 200 'OK' 'application/dxf' $out
      } catch {
        $code = $_.Exception.Message
        if ($code -notmatch '^ERR_') { Write-Log ('CONVERT_ERROR ' + $code); $code = 'ERR_CONVERT_FAILED' }
        else { Write-Log ('CONVERT_ERROR ' + $code) }
        $detail = ((@($script:ConvLog) | Select-Object -Last 6) -join ' | ') -replace '[^\x20-\x7E]', '?'
        Send-Text $stream 500 'Internal Server Error' ($code + "`n" + $detail)
      } finally {
        Remove-Item -LiteralPath $td -Recurse -Force -ErrorAction SilentlyContinue
      }
      continue
    }

    if ($method -eq 'GET') {
      $rel = $path.TrimStart('/')
      if ($rel -match '\.\.' -or $rel -match '^[A-Za-z]:' -or $rel.StartsWith('\')) { Send-Text $stream 403 'Forbidden' 'ERR_FORBIDDEN'; continue }
      $file = Join-Path $root ([Uri]::UnescapeDataString($rel) -replace '/', '\')
      $full = [IO.Path]::GetFullPath($file)
      if (-not $full.StartsWith([IO.Path]::GetFullPath($root), [StringComparison]::OrdinalIgnoreCase)) { Send-Text $stream 403 'Forbidden' 'ERR_FORBIDDEN'; continue }
      if (Test-Path -LiteralPath $full -PathType Leaf) {
        Send-Response $stream 200 'OK' (Get-Mime $full) ([IO.File]::ReadAllBytes($full))
        continue
      }
      Send-Text $stream 404 'Not Found' 'ERR_NOT_FOUND'
      continue
    }

    Send-Text $stream 405 'Method Not Allowed' 'ERR_METHOD'
  }
  catch {
    if ($gotHeader) {
      Write-Log ('REQUEST_ERROR ' + $_.Exception.Message)
      try { if ($stream) { Send-Text $stream 500 'Internal Server Error' 'ERR_SERVER' } } catch { }
    }
  }
  finally {
    try { if ($stream) { $stream.Close() } } catch { }
    try { if ($client) { $client.Close() } } catch { }
  }
}

try { if ($listener) { $listener.Stop() } } catch { }
Write-Log 'SERVER_STOPPED'
