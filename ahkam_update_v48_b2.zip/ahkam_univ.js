/* ahkam_univ.js — القارئ العام لنص كروكي AutoCAD المصدَّر PDF (يعمل مع أي خط TrueType مضمَّن)
   الفكرة: AutoCAD يكتب داخل الخط المضمَّن (FontFile2) جدول cmap صحيحًا لكل حرف استُخدم فعلًا، حتى لو كان
   جدول ToUnicode الظاهر خاطئًا. نقرأ الخط من بايتات الـPDF مباشرةً (pdf.js يعيد بناء الخط ويفقد هذا الجدول)،
   فنحصل على: رقم الحرف المرسوم (glyph id) ← رمز Unicode، ثم نحوّل أشكال العرض (FExx) إلى الحرف الأصلي.
   - يعمل لـ Arial / Calibri / ArabicTypesetting / Andalus / Tahoma / Traditional Arabic ... دون جدول يدوي لكل خط.
   - أي حرف غير موجود في جدول الخط ⇒ يُعلَّم unknown ولا يُخمَّن (يعود النظام لـOCR/الرؤية لهذا الحقل فقط).
   - لا يعمل مع: نص محوَّل إلى أشكال (Convert all text to geometry) أو خطوط SHX المرسومة، ولا مع PDF ممسوح ضوئيًا.
   الاستعمال:
     const tables = await AhkamUniv.loadFontTables(pdfBytes);          // مرة واحدة لكل ملف
     const runs   = await AhkamUniv.readRuns(pdfjsLib, page, tables);   // مقاطع نص بإحداثيات العرض
     const lines  = AhkamUniv.buildLines(runs);                         // أسطر مرتبة يمين←يسار
*/
(function(root){
'use strict';

/* ---------- 1) تطبيع الحروف: أشكال العرض → الحرف الأساسي، والياء/الهاء/الكاف الفارسية → العربية ---------- */
const FIX={'\u06cc':'\u064a','\u06d2':'\u064a','\u06be':'\u0647','\u06c1':'\u0647','\u06d5':'\u0647','\u06a9':'\u0643'};
const norm=cp=>String.fromCodePoint(cp).normalize('NFKC').replace(/[\u06cc\u06d2\u06be\u06c1\u06d5\u06a9]/g,c=>FIX[c]);
const isPF=c=>(c>=0xfb50&&c<=0xfdff)||(c>=0xfe70&&c<=0xfeff);

/* ---------- 2) استخراج الخطوط المضمّنة من بايتات الـPDF ---------- */
const latin1=u8=>{let s='';for(let i=0;i<u8.length;i+=32768)s+=String.fromCharCode.apply(null,u8.subarray(i,i+32768));return s};
async function inflate(u8){
  const ds=new DecompressionStream('deflate');
  const out=await new Response(new Blob([u8]).stream().pipeThrough(ds)).arrayBuffer();
  return new Uint8Array(out);
}
/* يقرأ جدول cmap (صيغة 4 و12) ويعيد Map: glyphId → رمز Unicode (يفضّل الحرف الأساسي على شكل العرض) */
function parseCmap(u8){
  const dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength);
  const nt=dv.getUint16(4);let cmapOff=-1;
  for(let i=0;i<nt;i++){const o=12+16*i,tag=String.fromCharCode(u8[o],u8[o+1],u8[o+2],u8[o+3]);if(tag==='cmap')cmapOff=dv.getUint32(o+8)}
  if(cmapOff<0)return null;
  const n=dv.getUint16(cmapOff+2),inv=new Map();
  const put=(cp,gid)=>{
    if(!gid)return;
    const old=inv.get(gid);
    if(old===undefined||(isPF(old)&&!isPF(cp))||(isPF(old)===isPF(cp)&&cp<old))inv.set(gid,cp);
  };
  for(let i=0;i<n;i++){
    const plat=dv.getUint16(cmapOff+4+8*i),enc=dv.getUint16(cmapOff+6+8*i),so=cmapOff+dv.getUint32(cmapOff+8+8*i);
    if(!(plat===0||(plat===3&&(enc===1||enc===10))))continue;
    const fmt=dv.getUint16(so);
    if(fmt===4){
      const sc=dv.getUint16(so+6)/2,endO=so+14,startO=endO+2*sc+2,deltaO=startO+2*sc,rangeO=deltaO+2*sc;
      for(let s=0;s<sc;s++){
        const end=dv.getUint16(endO+2*s),start=dv.getUint16(startO+2*s),delta=dv.getInt16(deltaO+2*s),ro=dv.getUint16(rangeO+2*s);
        if(start===0xffff)continue;
        for(let c=start;c<=end;c++){
          let g;
          if(ro===0)g=(c+delta)&0xffff;
          else{const p=rangeO+2*s+ro+2*(c-start);if(p+2>u8.length)continue;g=dv.getUint16(p);if(g)g=(g+delta)&0xffff}
          put(c,g);
        }
      }
    }else if(fmt===12){
      const ng=dv.getUint32(so+12);
      for(let g=0;g<ng;g++){
        const o=so+16+12*g,s=dv.getUint32(o),e=dv.getUint32(o+4),gid=dv.getUint32(o+8);
        for(let c=s;c<=e&&c-s<70000;c++)put(c,gid+(c-s));
      }
    }
  }
  return inv;
}
/* يعيد { اسمالخط: [Map(gid→cp), ...] } لكل خط TrueType مضمَّن في الملف */
async function loadFontTables(pdfBytes){
  const u8=pdfBytes instanceof Uint8Array?pdfBytes:new Uint8Array(pdfBytes),s=latin1(u8);
  const objs=[],re=/(\d+)\s+(\d+)\s+obj\b/g;let m;
  while((m=re.exec(s)))objs.push({num:+m[1],bodyStart:m.index+m[0].length,start:m.index});
  const byNum=new Map();
  objs.forEach((o,i)=>{o.end=i+1<objs.length?objs[i+1].start:s.length;byNum.set(o.num,o)});
  const tables={};
  for(const o of objs){
    const body=s.slice(o.bodyStart,Math.min(o.end,o.bodyStart+4000));
    if(body.indexOf('/FontFile2')<0||body.indexOf('/FontName')<0)continue;
    const fm=body.match(/\/FontFile2\s+(\d+)\s+\d+\s+R/),nm=body.match(/\/FontName\s*\/([^\s\/<>\[\]()]+)/);
    if(!fm||!nm)continue;
    const fo=byNum.get(+fm[1]);if(!fo)continue;
    const sIdx=s.indexOf('stream',fo.bodyStart);if(sIdx<0||sIdx>=fo.end)continue;
    let ds=sIdx+6;if(s[ds]==='\r')ds++;if(s[ds]==='\n')ds++;
    const eIdx=s.lastIndexOf('endstream',fo.end);
    const dict=s.slice(fo.bodyStart,sIdx);
    let data=u8.subarray(ds,eIdx);
    const lm=dict.match(/\/Length\s+(\d+)(?!\s+\d+\s+R)/);
    if(lm&&ds+ +lm[1]<=eIdx+2)data=u8.subarray(ds,ds+ +lm[1]);
    else while(data.length&&(data[data.length-1]===10||data[data.length-1]===13))data=data.subarray(0,data.length-1);
    try{
      if(/FlateDecode/.test(dict)){
        try{data=await inflate(data)}
        catch(e1){data=await inflate(data.subarray(0,data.length-1))}   // بايت زائد قبل endstream
      }
      const inv=parseCmap(data);
      if(!inv)continue;
      const name=nm[1].replace(/^[A-Z]{6}\+/,'');
      (tables[name]=tables[name]||[]).push(inv);
    }catch(e){/* خط تالف: نتجاهله */}
  }
  return tables;
}

/* ---------- 3) فك مجموعة أرقام حروف إلى نص منطقي ---------- */
function decodeGlyphs(codes,uniFallback,inv){
  const toks=[];let unknown=0;
  for(let k=0;k<codes.length;k++){
    const cp=inv&&inv.get(codes[k]);
    if(cp!==undefined){toks.push(norm(cp));continue}
    const u=uniFallback&&uniFallback[k];
    if(u&&/^[\x20-\x7e]$/.test(u)){toks.push(u);continue}
    toks.push('\u0000');unknown++;
  }
  const hasAr=toks.some(t=>/[\u0600-\u06ff]/.test(t));
  let text;
  if(hasAr)text=toks.slice().reverse().join('').replace(/[0-9\/.\-]+/g,x=>[...x].reverse().join(''));  // رُسم يسار←يمين ⇒ نعكس لنص منطقي
  else text=toks.join('');
  return{text,unknown};
}

/* ---------- 4) مقاطع النص بإحداثيات العرض (يراعي تدوير الصفحة) ---------- */
const mul=(a,b)=>[a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3],a[4]*b[0]+a[5]*b[2]+b[4],a[4]*b[1]+a[5]*b[3]+b[5]];
async function readRuns(lib,page,tables){
  const OPS=lib.OPS,ol=await page.getOperatorList(),vt=page.getViewport({scale:1}).transform;
  let ctm=[1,0,0,1,0,0],tm=[1,0,0,1,0,0],tlm=[1,0,0,1,0,0],font=null,fsize=0,hs=1,cs=0,ws=0;
  const st=[],runs=[],fontInfo={};
  const info=id=>{
    if(id in fontInfo)return fontInfo[id];
    let name='',inv=null;
    try{if(page.commonObjs.has(id))name=String((page.commonObjs.get(id)||{}).name||'')}catch(e){}
    const key=name.replace(/^[A-Z]{6}\+/,'');
    const cands=tables[key]||[];
    inv=cands.length===1?cands[0]:(cands[0]||null);
    return fontInfo[id]={name:key,cands,inv};
  };
  for(let i=0;i<ol.fnArray.length;i++){
    const f=ol.fnArray[i],a=ol.argsArray[i];
    switch(f){
      case OPS.save:st.push({ctm:ctm.slice(),font,fsize});break;
      case OPS.restore:{const s=st.pop();if(s){ctm=s.ctm;font=s.font;fsize=s.fsize}break}
      case OPS.transform:ctm=mul(a,ctm);break;
      case OPS.paintFormXObjectBegin:st.push({ctm:ctm.slice(),font,fsize});if(a&&a[0])ctm=mul(a[0],ctm);break;
      case OPS.paintFormXObjectEnd:{const s=st.pop();if(s){ctm=s.ctm;font=s.font;fsize=s.fsize}break}
      case OPS.beginText:tm=[1,0,0,1,0,0];tlm=tm.slice();break;
      case OPS.setTextMatrix:{const mm=Array.from(a.length===1&&typeof a[0]==='object'?a[0]:a);tm=mm;tlm=mm.slice();break}
      case OPS.moveText:tlm=mul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case OPS.setLeadingMoveText:tlm=mul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case OPS.setFont:font=a[0];fsize=a[1];break;
      case OPS.setCharSpacing:cs=a[0];break;
      case OPS.setWordSpacing:ws=a[0];break;
      case OPS.setHScale:hs=a[0]/100;break;
      case OPS.showText:{
        const gl=(a[0]||[]).filter(g=>g&&typeof g==='object');if(!gl.length)break;
        let adv=0;for(const g of gl)adv+=(g.width||0)*fsize*0.001*hs+cs*hs+(g.isSpace?ws*hs:0);
        const m=mul(tm,ctm),sx=Math.hypot(m[0],m[1]),sy=Math.hypot(m[2],m[3]);
        const w=Math.abs(adv)*sx,h=Math.abs(fsize)*sy;
        const ox=vt[0]*m[4]+vt[2]*m[5]+vt[4],oy=vt[1]*m[4]+vt[3]*m[5]+vt[5];
        let ux=vt[0]*m[0]+vt[2]*m[1],uy=vt[1]*m[0]+vt[3]*m[1];const ln=Math.hypot(ux,uy)||1;ux/=ln;uy/=ln;
        tm=mul([1,0,0,1,adv,0],tm);
        if(Math.abs(uy)>0.25||ux<0)break;                       // نص رأسي/مقلوب
        const fi=info(font);if(!fi.inv)break;                   // خط بلا جدول مضمَّن
        const codes=gl.map(g=>g.originalCharCode);
        // عند تكرار اسم الخط بجداول مختلفة نختار الجدول الذي يغطي كل الأرقام المستخدمة
        let inv=fi.inv;if(fi.cands.length>1){const full=fi.cands.find(c=>codes.every(x=>c.has(x)));if(full)inv=full}
        const d=decodeGlyphs(codes,gl.map(g=>g.unicode||''),inv);
        runs.push({x0:ox,x1:ox+w,cy:oy-h*0.35,h,text:d.text,unknown:d.unknown,font:fi.name});
        break}
    }
  }
  return runs;
}

/* ---------- 5) تجميع الأسطر (يمين ← يسار) ---------- */
function buildLines(runs){
  const rs=runs.filter(r=>r.text!=='').sort((a,b)=>a.cy-b.cy),rows=[];
  for(const r of rs){
    let row=rows.find(o=>Math.abs(o.cy-r.cy)<=0.4*Math.max(o.h,r.h));
    if(!row){row={cy:r.cy,h:r.h,rs:[]};rows.push(row)}
    row.rs.push(r);row.cy=(row.cy*(row.rs.length-1)+r.cy)/row.rs.length;row.h=Math.max(row.h,r.h);
  }
  const lines=[];
  for(const row of rows){
    const arr=row.rs.slice().sort((a,b)=>(b.x0+b.x1)-(a.x0+a.x1));
    let seg=[];
    const flush=()=>{
      if(!seg.length)return;
      let txt='',unknown=0;const fonts=new Set();
      for(let i=0;i<seg.length;i++){const r=seg[i];if(i>0&&seg[i-1].x0-r.x1>0.12*row.h)txt+=' ';txt+=r.text;unknown+=r.unknown;fonts.add(r.font)}
      txt=txt.replace(/\s+/g,' ').trim();
      if(txt)lines.push({text:txt,x0:Math.min(...seg.map(r=>r.x0)),x1:Math.max(...seg.map(r=>r.x1)),cy:row.cy,h:row.h,unknown,fonts:[...fonts]});
      seg=[];
    };
    for(const r of arr){if(seg.length&&seg[seg.length-1].x0-r.x1>1.8*row.h)flush();seg.push(r)}
    flush();
  }
  return lines;
}

/* ---------- 6) التحقق من رقم الهوية/الإقامة السعودي (خانة فحص Luhn) ---------- */
function saudiIdOk(s){
  s=String(s||'');if(!/^[12]\d{9}$/.test(s))return false;
  let t=0;for(let i=0;i<10;i++){let d=+s[i];if(i%2===0){d*=2;if(d>9)d-=9}t+=d}
  return t%10===0;
}

const API={loadFontTables,readRuns,buildLines,decodeGlyphs,parseCmap,saudiIdOk,norm};
root.AhkamUniv=API;
if(typeof module!=='undefined'&&module.exports)module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
