/* ahkam_read.js — قارئ الكروكي المساحي الهيكلي (v53)
   يعمل على كروكي AutoCAD المصدَّر PDF بأي تدوير (0/90/180/270) وأي تخطيط جدول، دون مواضع ثابتة:
   1) يقرأ حروف النص مباشرةً من أرقام الحروف المرسومة (ahkam_glyph.js) بإحداثيات العرض الفعلية (يراعي تدوير الصفحة)
   2) يجمّع الحروف في أسطر ثم يصنّف كل سطر بمحتواه (رقم طلب/سجل مدني/منطقة/مدينة/استخدام/اسم/موقع) وبموضعه النسبي
   3) القيم المرسومة كخطوط فقط (التاريخ الهجري) تُقرأ بـOCR أرقام على شريط الصفحة مع تصويت بين عدة تمريرات */
(function(root){
'use strict';
const P=()=>root.AhkamPdf,G=()=>root.AhkamGlyph,T=()=>root.AhkamTpl,U=()=>root.AhkamUniv;
const nk=s=>P().nk(s);
const mul=(a,b)=>[a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3],a[4]*b[0]+a[5]*b[2]+b[4],a[4]*b[1]+a[5]*b[3]+b[5]];
const isCalibri=n=>/(^|\+)Calibri/i.test(String(n||''));
const hasAr=s=>/[\u0600-\u06FF]/.test(s);

/* ---------- 1) مقاطع النص بإحداثيات العرض (أصل أعلى-يسار) ---------- */
async function vecRuns(lib,page,vt,tables){
  const OPS=lib.OPS,ol=await page.getOperatorList();
  let ctm=[1,0,0,1,0,0],tm=[1,0,0,1,0,0],tlm=[1,0,0,1,0,0],font=null,fsize=0,hs=1,cs=0,ws=0;
  const st=[],runs=[],fontOk={};
  /* لكل خط: هل هو Calibri (جدول ahkam_glyph) وهل في الملف جدول cmap مضمَّن له (ahkam_univ) */
  const okFont=id=>{
    if(id in fontOk)return fontOk[id];
    let name='';try{if(page.commonObjs.has(id))name=String((page.commonObjs.get(id)||{}).name||'')}catch(e){}
    const key=name.replace(/^[A-Z]{6}\+/,''),cands=(tables&&tables[key])||[];
    return fontOk[id]={cal:isCalibri(name),cands,inv:cands[0]||null};
  };
  for(let i=0;i<ol.fnArray.length;i++){
    const f=ol.fnArray[i],a=ol.argsArray[i];
    switch(f){
      case OPS.save:st.push({ctm:ctm.slice(),font,fsize});break;
      case OPS.restore:{const s=st.pop();if(s){ctm=s.ctm;font=s.font;fsize=s.fsize}break}
      case OPS.transform:ctm=mul(a,ctm);break;
      case OPS.paintFormXObjectBegin:st.push({ctm:ctm.slice(),font,fsize});if(a&&a[0])ctm=mul(a[0],ctm);break;
      case OPS.paintFormXObjectEnd:{const s=st.pop();if(s){ctm=s.ctm;font=s.font;fsize=s.fsize}break}
      case OPS.beginText:tm=[1,0,0,1,0,0];tlm=tm.slice();break;
      case OPS.setTextMatrix:{const mm=Array.from(a.length===1&&typeof a[0]==='object'?a[0]:a);tm=mm;tlm=mm.slice();break}
      case OPS.moveText:tlm=mul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case OPS.setLeadingMoveText:tlm=mul([1,0,0,1,a[0],a[1]],tlm);tm=tlm.slice();break;
      case OPS.setFont:font=a[0];fsize=a[1];break;
      case OPS.setCharSpacing:cs=a[0];break;
      case OPS.setWordSpacing:ws=a[0];break;
      case OPS.setHScale:hs=a[0]/100;break;
      case OPS.showText:{
        const gl=(a[0]||[]).filter(g=>g&&typeof g==='object');if(!gl.length)break;
        let adv=0;for(const g of gl)adv+=(g.width||0)*fsize*0.001*hs+cs*hs+(g.isSpace?ws*hs:0);
        const m=mul(tm,ctm),sx=Math.hypot(m[0],m[1]),sy=Math.hypot(m[2],m[3]);
        const w=Math.abs(adv)*sx,h=Math.abs(fsize)*sy;
        const ox=vt[0]*m[4]+vt[2]*m[5]+vt[4],oy=vt[1]*m[4]+vt[3]*m[5]+vt[5];
        let ux=vt[0]*m[0]+vt[2]*m[1],uy=vt[1]*m[0]+vt[3]*m[1];const ln=Math.hypot(ux,uy)||1;ux/=ln;uy/=ln;
        const fi=okFont(font),cal=!!(fi.cal||fi.inv);
        tm=mul([1,0,0,1,adv,0],tm);
        if(Math.abs(uy)>0.25||ux<0)break;                 // نص رأسي/مقلوب: عناوين جانبية لا نحتاجها
        const codes=gl.map(g=>g.originalCharCode);
        let text='',unknown=0,inferred=0;
        if(cal){
          /* عند تكرار اسم الخط بجداول مختلفة نختار الجدول الذي يغطي كل الأرقام المستخدمة */
          let inv=fi.inv;if(fi.cands.length>1){const full=fi.cands.find(c=>codes.every(x=>c.has(x)));if(full)inv=full}
          const toks=[];
          for(let k=0;k<gl.length;k++){
            const c=codes[k],u=gl[k].unicode||'';
            const cp=inv&&inv.get(c);
            if(cp!==undefined){toks.push(U().norm(cp));continue}            // 1) جدول الخط المضمَّن (دقيق)
            if(fi.cal){const d=G().decode([c]);if(!d.unknown){toks.push(d.text);inferred+=d.inferred;continue}}   // 2) جدول Calibri
            if(/^[\x20-\x7e]$/.test(u)){toks.push(u);continue}              // 3) رمز ترقيم/رقم
            toks.push('\u0000');unknown++;                                  // 4) مجهول: لا نخمّن
          }
          if(toks.some(t=>hasAr(t)))text=toks.reverse().join('').replace(/[0-9\/.\-]+/g,mm=>[...mm].reverse().join(''));
          else text=toks.join('');
        }else{
          const u=gl.map(g=>g.unicode||'').join('');
          if(hasAr(u))break;                                // عربي في خط بلا جدول: لا نخمّن
          text=u;
        }
        runs.push({x0:ox,x1:ox+w,cy:oy-h*0.35,h,text,unknown,inferred,cal});
        break}
    }
  }
  return runs;
}

/* ---------- 2) تجميع الأسطر ---------- */
function buildLines(runs){
  const rs=runs.filter(r=>r.text!=='').sort((a,b)=>a.cy-b.cy);
  const rows=[];
  for(const r of rs){
    let row=rows.find(o=>Math.abs(o.cy-r.cy)<=0.4*Math.max(o.h,r.h));
    if(!row){row={cy:r.cy,h:r.h,rs:[]};rows.push(row)}
    row.rs.push(r);row.cy=(row.cy*(row.rs.length-1)+r.cy)/row.rs.length;row.h=Math.max(row.h,r.h);
  }
  const lines=[];
  for(const row of rows){
    const arr=row.rs.slice().sort((a,b)=>(b.x0+b.x1)-(a.x0+a.x1));   // يمين ← يسار
    let seg=[];
    const flush=()=>{
      if(!seg.length)return;
      let txt='',unknown=0,inferred=0,h=0;
      for(let i=0;i<seg.length;i++){
        const r=seg[i];
        if(i>0){const gap=seg[i-1].x0-r.x1;if(gap>0.12*row.h)txt+=' '}
        txt+=r.text;unknown+=r.unknown;inferred+=r.inferred;if(r.text.trim())h=Math.max(h,r.h);
      }
      txt=txt.replace(/\s+/g,' ').trim();
      if(txt){const x0=Math.min(...seg.map(r=>r.x0)),x1=Math.max(...seg.map(r=>r.x1));
        lines.push({text:txt,x0,x1,cx:(x0+x1)/2,cy:row.cy,h:h||row.h,unknown,inferred})}
      seg=[];
    };
    for(const r of arr){
      if(seg.length){const gap=seg[seg.length-1].x0-r.x1;if(gap>1.8*row.h)flush()}
      seg.push(r);
    }
    flush();
  }
  return lines;
}

/* ---------- 3) مطابقة القوائم (حرف مجهول \0 يطابق أي حرف) ---------- */
function levW(a,b){
  const m=a.length,n=b.length;if(!m)return n;if(!n)return m;
  let p=[...Array(n+1).keys()];
  for(let i=1;i<=m;i++){const c=[i];for(let j=1;j<=n;j++){const eq=a[i-1]==='\u0000'||a[i-1]===b[j-1];c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(eq?0:1))}p=c}
  return p[n];
}
function snapW(text,list){
  const c=nk(text).replace(/\s+/g,' ');if(c.replace(/\u0000/g,'').length<2)return null;
  let best=null;
  for(const name of list){
    const t=nk(name);const d=levW(c,t),lim=Math.max(1,Math.floor(t.length/4));
    if(d<=lim&&Math.abs(c.length-t.length)<=2&&(!best||d<best.d))best={name,d,wild:c.includes('\u0000')};
  }
  return best;
}

/* ---------- 4) تصنيف الأسطر ---------- */
const STOP=/(تطبيق|فرز|افراز|دمج|تجزئ|تقسيم|اصدار|استبدال|الغرض|ترخيص|رقم|بدون|مخطط|قطع)/;
function classify(lines,W,H){
  const REG=T().REGIONS,CIT=T().CITIES,USE=T().USES.concat(['أرض فضاء','أرض بيضاء','حكومي','استثماري','تعليمي','صحي','ديني','مرفق عام'].filter(x=>!T().USES.includes(x)));
  const F={},used=new Set();
  const put=(k,v,conf,how,line)=>{if(v&&(!F[k]||conf>F[k].conf)){F[k]={value:v,conf,how,page:1,label:'تحليل المحتوى',line}}if(line)used.add(line)};
  const clean=s=>P().clean(s);
  let pool=lines.filter(l=>l.cx>0.5*W&&l.cy<0.5*H);
  if(pool.length<6)pool=lines.slice();
  // الرقم المدني
  let idL=null;
  for(const l of pool){const m=clean(l.text).match(/(?<!\d)[12]\d{9}(?!\d)/);if(m){idL=l;put('رقم السجل',m[0],0.98,'حروف الملف',l);break}}
  // رقم الطلب
  const reqs=pool.filter(l=>l!==idL&&/^\d{5,}([\/\-]\d+)?$/.test(clean(l.text))).sort((a,b)=>a.cy-b.cy);
  if(reqs.length)put('رقم الطلب',clean(reqs[0].text),0.97,'حروف الملف',reqs[0]);
  // المنطقة
  let regL=null,rb=null;
  for(const l of pool){if(used.has(l)||l.text.length>24)continue;const s=snapW(l.text,REG);if(s&&(!rb||s.d<rb.d||(s.d===rb.d&&l.cy<regL.cy))){rb=s;regL=l}}
  if(regL)put('المنطقة',rb.name,rb.d===0?0.97:0.88,'حروف الملف + قائمة المناطق',regL);
  // المدينة (بنفس عمود المنطقة وأسفلها، وإلا أي سطر)
  let cityL=null,cb=null;
  const colOK=l=>!regL||Math.abs(l.cx-regL.cx)<=0.07*W;
  for(const l of pool){if(used.has(l)||l.text.length>24||!colOK(l))continue;if(regL&&l.cy<=regL.cy)continue;
    const s=snapW(l.text,CIT);if(s&&(!cb||s.d<cb.d||(s.d===cb.d&&l.cy<cityL.cy))){cb=s;cityL=l}}
  if(cityL)put('المدينة',cb.name,cb.d===0&&!cb.wild?0.97:0.9,'حروف الملف + قائمة المدن',cityL);
  // الاستخدام
  let useL=null,ub=null;
  for(const l of pool){if(used.has(l)||l.text.length>20)continue;
    let s=snapW(l.text,USE);
    if(!s){const t=nk(l.text);const hasS=/سكني/.test(t),hasT=/تجاري/.test(t);if(hasS&&hasT)s={name:'سكني تجاري',d:1};else if(/^(زراعي|صناعي|حكومي|استثماري)$/.test(t))s={name:t,d:0}}
    if(s&&(!ub||s.d<ub.d)){ub=s;useL=l}}
  if(useL)put('الاستخدام',ub.name,ub.d===0?0.97:0.88,'حروف الملف + قائمة الاستخدامات',useL);
  // اسم المالك: أقرب سطر عربي (≥2 كلمة) للرقم المدني وبأكبر خط
  const wc=l=>l.text.split(' ').filter(Boolean).length;
  const cand=pool.filter(l=>!used.has(l)&&hasAr(l.text)&&!/\d/.test(l.text)&&wc(l)>=2&&!STOP.test(nk(l.text))&&!l.text.includes('\u0000'));
  let nameL=null;
  if(idL){
    const near=cand.filter(l=>Math.abs(l.cy-idL.cy)<=0.12*H).sort((a,b)=>(b.h-a.h)||(Math.abs(a.cy-idL.cy)-Math.abs(b.cy-idL.cy)));
    nameL=near[0]||null;
  }
  if(!nameL){const c2=cand.filter(l=>wc(l)>=3).sort((a,b)=>b.h-a.h);nameL=c2[0]||null}
  if(nameL)put('اسم المالك',nameL.text,nameL.inferred?0.88:0.97,nameL.inferred?'حروف الملف (بعضها مستنتج)':'حروف الملف',nameL);
  // الموقع: أكبر خط بين المدينة والاستخدام في نفس العمود
  if(cityL){
    const yTop=cityL.cy,yBot=useL?useL.cy:cityL.cy+0.09*H;
    const c3=pool.filter(l=>!used.has(l)&&hasAr(l.text)&&l.cy>yTop+1&&l.cy<yBot-1&&Math.abs(l.cx-cityL.cx)<=0.08*W&&!STOP.test(nk(l.text))&&l.text.replace(/[^\u0600-\u06FF]/g,'').length>=2)
      .sort((a,b)=>(b.h-a.h)||(a.cy-b.cy));
    if(c3.length){
      let v=c3[0].text.replace(/\u0000/g,'').replace(/\s*-\s*/g,'-').trim();
      const ws=v.split(' ');if(ws.length>1&&nk(ws[0])==='حي')v=ws.slice(1).join(' ');
      const dist=T().snap([v],T().DISTRICTS);
      if(dist&&dist.d===0)put('الموقع',dist.name,0.97,'حروف الملف + قائمة الأحياء',c3[0]);
      else put('الموقع',v,c3[0].unknown?0.8:0.92,'حروف الملف',c3[0]);
    }
  }
  // التاريخ من نص الملف إن وُجد (أحدث تاريخ هجري سنته 1430–1470)
  const ds=[];for(const l of lines){const h=P().parseHijri(l.text);if(h&&h.y>=1430&&h.y<=1470)ds.push(h)}
  if(ds.length){ds.sort((a,b)=>b.y-a.y||b.m-a.m||b.d-a.d);const h=ds[0];put('التاريخ',h.d+'/'+h.m+'/'+h.y,0.95,'حروف الملف',null)}
  return F;
}

/* ---------- 5) OCR أرقام لتاريخ مرسوم كخطوط ---------- */
let digWorker=null;
function loadScript(src){return new Promise((res,rej)=>{if(root.Tesseract)return res();const s=document.createElement('script');s.src=src;s.onload=res;s.onerror=()=>rej(new Error('ERR_OCR_MISSING'));document.head.appendChild(s)})}
async function getDigitWorker(){
  if(digWorker)return digWorker;
  const r=await fetch('/ocr/ready.txt?t='+Date.now()).catch(()=>null);
  if(!r||!r.ok)throw new Error('ERR_OCR_MISSING');
  await loadScript('/ocr/tesseract.min.js');
  const w=await root.Tesseract.createWorker('eng',1,{workerPath:'/ocr/worker.min.js',corePath:'/ocr',langPath:'/ocr/lang',gzip:false,workerBlobURL:false});
  return digWorker=w;
}
async function cropCanvas(page,W,H,x0,y0,x1,y1,S){
  const vp=page.getViewport({scale:S});
  const px0=Math.floor(x0*W*S),py0=Math.floor(y0*H*S),pw=Math.ceil((x1-x0)*W*S),ph=Math.ceil((y1-y0)*H*S);
  const pad=20,cv=document.createElement('canvas');cv.width=pw+pad*2;cv.height=ph+pad*2;
  const cx=cv.getContext('2d',{willReadFrequently:true});cx.fillStyle='#fff';cx.fillRect(0,0,cv.width,cv.height);
  const tmp=document.createElement('canvas');tmp.width=pw;tmp.height=ph;
  const tx=tmp.getContext('2d',{willReadFrequently:true});tx.fillStyle='#fff';tx.fillRect(0,0,pw,ph);
  await page.render({canvasContext:tx,viewport:vp,transform:[1,0,0,1,-px0,-py0]}).promise;
  cx.drawImage(tmp,pad,pad);
  const im=cx.getImageData(0,0,cv.width,cv.height),d=im.data;
  for(let i=0;i<d.length;i+=4){const l=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2],v=l<150?0:255;d[i]=d[i+1]=d[i+2]=v}
  cx.putImageData(im,0,0);return cv;
}
async function ocrDate(page,W,H,say){
  const w=await getDigitWorker();
  const votes=new Map();
  for(const [S,psm] of [[4,11],[5,6],[6,11],[4,6]]){
    say&&say('قراءة التاريخ بصريًا...');
    await w.setParameters({tessedit_char_whitelist:'0123456789/-.',tessedit_pageseg_mode:String(psm),user_defined_dpi:'300'});
    const cv=await cropCanvas(page,W,H,0.60,0.24,0.995,0.46,S);
    const r=await w.recognize(cv);
    const txt=String(r.data.text||'').replace(/\s*\/\s*/g,'/');
    for(const m of txt.matchAll(/(?<!\d)(\d{1,2})\/(\d{1,2})\/(1[34]\d{2})(?!\d)/g)){
      const d=+m[1],mo=+m[2],y=+m[3];if(y<1430||y>1470||mo<1||mo>12||d<1||d>30)continue;
      const k=d+'/'+mo+'/'+y;votes.set(k,(votes.get(k)||0)+1);
    }
  }
  let best=null;for(const [k,n] of votes)if(!best||n>best.n)best={k,n};
  return best;
}

/* ---------- الواجهة ---------- */
async function readPdf(lib,buf,say){
  let tables={};
  try{if(U())tables=await U().loadFontTables(new Uint8Array(buf.slice(0)))}catch(e){console.warn('ahkam_univ',e)}   // قبل getDocument لأنه قد يفصل المخزن
  const pdf=await lib.getDocument({data:new Uint8Array(buf)}).promise;
  const page=await pdf.getPage(1),vp=page.getViewport({scale:1}),W=vp.width,H=vp.height;
  say&&say('قراءة حروف الكروكي...');
  const runs=await vecRuns(lib,page,vp.transform,tables);
  const calRuns=runs.filter(r=>r.cal&&r.text.trim());
  if(calRuns.length<6)return {fields:{},pages:pdf.numPages,text:'',hasText:false,viaVector:false,score:0};
  const lines=buildLines(runs);
  const fields=classify(lines,W,H);
  let ocrNote='';
  if(!fields['التاريخ']){
    try{const d=await ocrDate(page,W,H,say);if(d)fields['التاريخ']={value:d.k,conf:d.n>=2?0.9:0.7,how:'OCR أرقام ('+d.n+' من 4 تمريرات)',page:1,label:'التاريخ المرسوم'};}
    catch(e){ocrNote=(e&&e.message)||String(e)}
  }
  const KEYS=['رقم الطلب','اسم المالك','رقم السجل','الاستخدام','المنطقة','المدينة','الموقع','التاريخ'];
  const score=KEYS.filter(k=>fields[k]&&fields[k].conf>=0.85).length;
  for(const k in fields)delete fields[k].line;
  return {fields,pages:pdf.numPages,hasText:true,viaVector:true,viaGlyph:true,viaUniv:Object.keys(tables).length>0,glyphInferred:Object.values(fields).some(f=>/مستنتج/.test(f.how)),
    ocrError:ocrNote==='ERR_OCR_MISSING'?'ERR_OCR_MISSING':'',score,arCount:999,
    text:lines.map(l=>l.text+'   ['+Math.round(l.cx)+','+Math.round(l.cy)+' h'+l.h.toFixed(1)+']').join('\n')};
}
root.AhkamRead={readPdf,buildLines,classify,vecRuns,snapW};
})(typeof window!=='undefined'?window:globalThis);
