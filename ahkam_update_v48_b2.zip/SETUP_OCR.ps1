# One-time OCR download (needs internet)
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$o=Join-Path $root 'ocr'; $l=Join-Path $o 'lang'
New-Item -ItemType Directory -Force -Path $l | Out-Null
$js='https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/'
$core='https://cdn.jsdelivr.net/npm/tesseract.js-core@5.1.1/'
$items=@(
 @{u=$js+'tesseract.min.js';f='tesseract.min.js'},
 @{u=$js+'worker.min.js';f='worker.min.js'},
 @{u=$core+'tesseract-core.wasm.js';f='tesseract-core.wasm.js'},
 @{u=$core+'tesseract-core-simd.wasm.js';f='tesseract-core-simd.wasm.js'},
 @{u=$core+'tesseract-core-lstm.wasm.js';f='tesseract-core-lstm.wasm.js'},
 @{u=$core+'tesseract-core-simd-lstm.wasm.js';f='tesseract-core-simd-lstm.wasm.js'}
)
foreach($i in $items){ Write-Host ('Downloading '+$i.f); Invoke-WebRequest -UseBasicParsing -Uri $i.u -OutFile (Join-Path $o $i.f) }
$langs=@('ara','eng')
foreach($n in $langs){
  $dst=Join-Path $l ($n+'.traineddata'); $ok=$false
  foreach($base in @('https://github.com/tesseract-ocr/tessdata_best/raw/main/','https://raw.githubusercontent.com/tesseract-ocr/tessdata_best/main/')){
    try{ Write-Host ('Downloading '+$n+'.traineddata'); Invoke-WebRequest -UseBasicParsing -Uri ($base+$n+'.traineddata') -OutFile $dst; $ok=$true; break }catch{ Write-Host $_.Exception.Message }
  }
  if(-not $ok){ throw ('Failed to download '+$n) }
}
Set-Content -LiteralPath (Join-Path $o 'ready.txt') -Value 'ok' -Encoding ASCII
Write-Host ''; Write-Host 'OCR is ready. Restart START_AHKAM.cmd and read the sketch again.' -ForegroundColor Green
