# Downloads the map/zip libraries once into the lib folder so the tool never depends on a CDN again.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
$root = $PSScriptRoot
$libDir = Join-Path $root 'lib'
$items = @(
  @('leaflet.js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', 100000),
  @('leaflet.css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', 5000),
  @('images/layers.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/layers.png', 300),
  @('images/layers-2x.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/layers-2x.png', 300),
  @('images/marker-icon.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png', 300),
  @('images/marker-icon-2x.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png', 300),
  @('images/marker-shadow.png', 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png', 300),
  @('shp.min.js', 'https://cdn.jsdelivr.net/npm/shpjs@6.1.0/dist/shp.min.js', 20000),
  @('proj4.js', 'https://cdn.jsdelivr.net/npm/proj4@2.11.0/dist/proj4.js', 20000)
)
$fail = 0
foreach ($it in $items) {
  $rel = [string]$it[0]
  $dst = Join-Path $libDir ($rel -replace '/', '\')
  if ((Test-Path -LiteralPath $dst -PathType Leaf) -and ((Get-Item -LiteralPath $dst).Length -ge [int]$it[2])) { Write-Host ('OK      ' + $rel); continue }
  try {
    $dir = Split-Path -Parent $dst
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $tmp = $dst + '.part'
    Invoke-WebRequest -UseBasicParsing -Uri ([string]$it[1]) -OutFile $tmp -TimeoutSec 60
    if ((Get-Item -LiteralPath $tmp).Length -lt [int]$it[2]) { Remove-Item -LiteralPath $tmp -Force; throw 'file too small' }
    Move-Item -LiteralPath $tmp -Destination $dst -Force
    Write-Host ('DOWNLOADED ' + $rel)
  } catch {
    $fail++
    Write-Host ('FAILED  ' + $rel + '  ' + $_.Exception.Message)
  }
}
if ($fail -eq 0) { Write-Host ''; Write-Host 'All libraries are ready. The tool now works without CDN access.' } else { Write-Host ''; Write-Host ($fail.ToString() + ' file(s) failed. Check the internet connection and run this again.') }
